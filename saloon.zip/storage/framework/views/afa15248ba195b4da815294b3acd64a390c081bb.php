
<?php $__env->startSection('website_content'); ?>
<?php echo $__env->make('website.layouts.breadcrumb', [
    'title' => $salon->name,
    'headerData' => __('Salon'),
    'url' => 'all-salons'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- ================================
    START BREADCRUMB AREA
================================= -->
<section class="breadcrumb-area bg-gradient-gray py-5">
    <div class="container">
        <div class="row">
            <div class="breadcrumb-content breadcrumb-content-2 d-flex flex-wrap align-items-end justify-content-between">
                <div class="section-heading display-flex">
                    <div class="salon-image mr-4">
                        <a href="<?php echo e($salon->imagePath .'/'. $salon->image); ?>" data-fancybox="gallery" class="d-block">
                            <img src="<?php echo e($salon->imagePath .'/'. $salon->image); ?>" alt="blog single image" width="300" height="200" class="radius-round" style="">
                        </a>
                    </div>
                    <div class="salon-desc">
                        <div class="d-flex align-items-center">
                            <h4 class="mb-0"> <?php echo e($salon->name); ?> </h4>
                        </div>
                        <p class="sec__desc py-2 font-size-17"><i class="la la-map-marker mr-1 text-color-2"></i>
                            <?php echo e($salon->city); ?>, <?php echo e($salon->state); ?>, <?php echo e($salon->country); ?>

                        </p>
                        <p class="pb-2 font-weight-medium font-size-17">
                            <?php if($salon->gender == "Male"): ?>
                                <i class="la la-mars mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Male')); ?>

                            <?php elseif($salon->gender == "Female"): ?>
                                <i class="la la-venus mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Female')); ?>

                            <?php else: ?>
                                <i class="la la-venus-mars mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Unisex')); ?>

                            <?php endif; ?>
                            <span class="category-link">
                                <?php echo e(__('Give service at :')); ?>

                                <?php if($salon->give_service == "Home"): ?>
                                    <?php echo e(__('layout.Home')); ?>

                                <?php elseif($salon->give_service == "Salon"): ?>
                                    <?php echo e(__('layout.Salon')); ?>

                                <?php else: ?>
                                    <?php echo e(__('layout.Both')); ?>

                                <?php endif; ?>
                            </span>
                        </p>

                        <?php $rating = $salon->rate; ?>
                        <div class="d-flex flex-wrap align-items-center">
                            <div class="star-rating-wrap d-flex align-items-center">
                                <div class="star-rating text-color-5 font-size-18">
                                    <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($rating >0): ?>
                                                <?php if($rating >0.5): ?>
                                                    <span class="ml-n1"><i class="la la-star"></i></span>
                                                <?php endif; ?>
                                            <?php else: ?> 
                                                <span class="ml-n1"><i class="la la-star-o"></i></span>
                                            <?php endif; ?>
                                            <?php $rating--; ?>
                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <p class="font-size-14 pl-2 font-weight-medium"><?php echo e($salon->rateCount); ?> <?php echo e(__('reviews')); ?></p>
                            </div>
                            <div class="timestamp font-weight-medium ml-3 pl-3 border-left border-left-color line-height-20">
                                
                                <?php if($today == "Close"): ?>
                                    <span class="text-color-4 mr-2"><?php echo e(__('layout.Now')); ?>:</span>
                                    <span class="badge bg-11 text-white"><?php echo e(__('layout.Closed')); ?></span>
                                <?php else: ?>
                                    <span class="text-color-4 mr-2"><?php echo e(__('layout.Open')); ?>:</span>
                                    <span> <?php echo e($today); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if(Auth::check()): ?>
                            <a href="<?php echo e(url('salon/' .$salon->salon_id .'/'. Str::slug($salon->name)) .'/booking'); ?>" class="theme-btn gradient-btn shadow-none add-listing-btn-hide mt-3">
                                </i> <?php echo e(__('layout.Book Now')); ?>

                            </a>
                        <?php else: ?>
                            <a href="#" class="theme-btn gradient-btn shadow-none add-listing-btn-hide mt-3"  data-toggle="modal" data-target="#loginModal">
                                </i> <?php echo e(__('layout.Book Now')); ?>

                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div><!-- end breadcrumb-content -->
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end breadcrumb-area -->
<!-- ================================
    END BREADCRUMB AREA
================================= -->


<!-- ================================
    START LISTING DETAIL AREA
================================= -->
<section class="listing-detail-area padding-top-60px padding-bottom-100px">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="listing-detail-wrap">
                    <div class="block-card mb-4">
                       <div class="block-card-header">
                           <h2 class="widget-title"> <?php echo e(__('layout.Description')); ?> </h2>
                           <div class="stroke-shape"></div>
                       </div><!-- end block-card-header -->
                        <div class="block-card-body">
                            <?php if(strlen($salon->desc) > 300): ?>
                                <p class="pb-3 font-weight-medium line-height-30">
                                    <?php echo e(substr($salon->desc,0,300)); ?>

                                    <span class="collapse collapse-content" id="showMoreOptionCollapse">
                                            <?php echo e(substr($salon->desc,300)); ?>

                                    </span>
                                </p>
                                <a class="collapse-btn" data-toggle="collapse" href="#showMoreOptionCollapse" role="button" aria-expanded="false" aria-controls="showMoreOptionCollapse">
                                    <span class="collapse-btn-hide"> <?php echo e(__('layout.Read More')); ?> <i class="la la-plus ml-1"></i></span>
                                    <span class="collapse-btn-show"> <?php echo e(__('layout.Read Less')); ?> <i class="la la-minus ml-1"></i></span>
                                </a>
                            <?php else: ?>
                                <p class="pb-3 font-weight-medium line-height-30">
                                    <?php echo e($salon->desc); ?>

                                </p>
                            <?php endif; ?>
                        </div><!-- end block-card-body -->
                    </div><!-- end block-card -->
                  
                    <div class="block-card mb-4">
                        <div class="block-card-header">
                            <h2 class="widget-title"><?php echo e(__('layout.Location / Contact')); ?></h2>
                            <div class="stroke-shape"></div>
                        </div><!-- end block-card-header -->
                        <div class="block-card-body">
                            <div class="map-container height-400">
                                <input type="hidden" value="<?php echo e($salon->latitude); ?>" name="latitude" id="latitude">
                                <input type="hidden" value="<?php echo e($salon->longitude); ?>" name="longitude" id="longitude">
                                <div id="map"></div>
                            </div>
                            <ul class="list-items list--items list-items-style-2 py-4">
                                <li><span class="text-color"><i class="la la-map mr-2 text-color-2 font-size-18"></i><?php echo e(__('layout.Address')); ?>:</span> <a href="https://maps.google.com/?q=<?php echo e($salon->latitude); ?>,<?php echo e($salon->longitude); ?>" target="_blank"> <?php echo e($salon->address); ?>, <?php echo e($salon->city); ?>-<?php echo e($salon->zipcode); ?>, <?php echo e($salon->state); ?>, <?php echo e($salon->country); ?> </a></li>
                                <li><span class="text-color"><i class="la la-phone mr-2 text-color-2 font-size-18"></i><?php echo e(__('layout.Phone')); ?>:</span><a href="tel:<?php echo e($salon->phone); ?>"> <?php echo e($salon->phone); ?> </a></li>
                                <?php if($salon->website != null): ?>
                                    <li><span class="text-color"><i class="la la-globe mr-2 text-color-2 font-size-18"></i><?php echo e(__('layout.Website')); ?>:</span><a href="<?php echo e($salon->website); ?>"><?php echo e($salon->website); ?></a></li>
                                <?php endif; ?>
                            </ul>
                        </div><!-- end block-card-body -->
                    </div><!-- end block-card -->
                    <div class="block-card mb-4">
                        <div class="block-card-header">
                            <h3 class="widget-title"> <?php echo e(__('layout.Services')); ?> <span class="ml-1 text-color-2"> (<?php echo e($salon->serviceCount); ?>) </span></h3>
                            <div class="stroke-shape"></div>
                        </div><!-- end block-card-header -->
                        <div class="cat-tabs row">
                            <div class="section-tab section-tab-layout-2 mb-4 col-lg-4">
                                <ul class="nav nav-tabs cat-nav" id="myTab" role="tablist">
                                    <?php $__currentLoopData = $salon->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e($loop->iteration == 1 ? 'active':''); ?>"  data-toggle="tab" href="#<?php echo e($cat->name); ?>" role="tab" aria-selected="true">
                                                <?php echo e($cat->name); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                             <div class="tab-content col-lg-8" id="myTabContent">
                                <?php $__currentLoopData = $salon->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tab-pane <?php echo e($loop->iteration == 1 ? 'active show':''); ?>" id="<?php echo e($cat->name); ?>" role="tabpanel" >
                                        <?php $__currentLoopData = $cat->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mini-list-card">
                                                <div class="mini-list-img">
                                                    <a href="#" class="d-block">
                                                        <img src="<?php echo e($service->imagePath .'/'. $service->image); ?>" alt="<?php echo e($service->name); ?>">
                                                    </a>
                                                </div><!-- end mini-list-img -->
                                                <div class="mini-list-body w-100">
                                                    <h4 class="mini-list-title display-inline-block"> <?php echo e($service->name); ?> </h4>
                                                    <span class="category-link after-none pl-0 font-size-15 font-weight-semi-bold float-right">
                                                       <?php echo e($service->price); ?> <?php echo e($setting->currency_symbol); ?>

                                                    </span><br>
                                                    <span class="category-link after-none pl-0 font-size-14 font-weight-medium">
                                                        <i class="la la-clock mr-1 listing-icon text-color-2"></i> <?php echo e($service->time); ?> <?php echo e(__('layout.Min')); ?>

                                                    </span>
                                                    <?php if($salon->gender == "Both"): ?>
                                                        <p class="pb-2 font-size-14 font-weight-medium">
                                                            <?php if($service->gender == "Male"): ?>
                                                                <i class="la la-mars mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Male')); ?>

                                                            <?php elseif($service->gender == "Female"): ?>
                                                                <i class="la la-venus mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Female')); ?>

                                                            <?php else: ?>
                                                                <i class="la la-venus-mars mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Unisex')); ?>

                                                            <?php endif; ?>
                                                        </p>
                                                    <?php endif; ?>
                                                </div><!-- end mini-list-body -->
                                            </div><!-- end mini-list-card -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </div>
                        </div>
                    </div><!-- end block-card -->
                  
                </div><!-- end listing-detail-wrap -->
            </div><!-- end col-lg-8 -->
            <div class="col-lg-4">
                <div class="sidebar mb-0">
                    <div class="sidebar-widget">
                        <h3 class="widget-title"> <?php echo e(__('layout.Opening Hours')); ?> </h3>
                        <div class="stroke-shape mb-4"></div>
                        <ul class="list-items">
                            <li class="d-flex justify-content-between"><?php echo e(__('layout.Monday')); ?>

                                <span class="<?php echo e(implode(" : ",$times[0]) == 'Close' ? 'text-color-2' : ''); ?>"><?php echo e(implode(" : ",$times[0])); ?></span>
                            </li>
                            <li class="d-flex justify-content-between"><?php echo e(__('layout.Tuesday')); ?> <span class="<?php echo e(implode(" : ",$times[1]) == 'Close' ? 'text-color-2' : ''); ?>"><?php echo e(implode(" : ",$times[1])); ?></span></li>
                            <li class="d-flex justify-content-between"><?php echo e(__('layout.Wednesday')); ?> <span class="<?php echo e(implode(" : ",$times[2]) == 'Close' ? 'text-color-2' : ''); ?>"><?php echo e(implode(" : ",$times[2])); ?></span></li>
                            <li class="d-flex justify-content-between"><?php echo e(__('layout.Thursday')); ?> <span class="<?php echo e(implode(" : ",$times[3]) == 'Close' ? 'text-color-2' : ''); ?>"><?php echo e(implode(" : ",$times[3])); ?></span></li>
                            <li class="d-flex justify-content-between"><?php echo e(__('layout.Friday')); ?> <span class="<?php echo e(implode(" : ",$times[4]) == 'Close' ? 'text-color-2' : ''); ?>"><?php echo e(implode(" : ",$times[4])); ?></span></li>
                            <li class="d-flex justify-content-between"><?php echo e(__('layout.Saturday')); ?> <span class="<?php echo e(implode(" : ",$times[5]) == 'Close' ? 'text-color-2' : ''); ?>"><?php echo e(implode(" : ",$times[5])); ?></span></li>
                            <li class="d-flex justify-content-between"><?php echo e(__('layout.Sunday')); ?> <span class="<?php echo e(implode(" : ",$times[6]) == 'Close' ? 'text-color-2' : ''); ?>"><?php echo e(implode(" : ",$times[6])); ?></span></li>
                        </ul>
                    </div><!-- end sidebar-widget -->
                    <div class="sidebar-widget">
                        <h3 class="widget-title"> <?php echo e(__('layout.Gallery')); ?> </h3>
                        <div class="stroke-shape mb-4"></div>
                        <div class="card-image after-none">
                            <!-- <div class="single-slider owl-trigger-action owl-trigger-action-3">
                                <?php $__currentLoopData = $salon->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-slider-item">
                                        <img src="<?php echo e($item->imagePath); ?><?php echo e($item->image); ?>" class="card__img" alt="blog image">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>  -->
                            <div class="photoset -square -portrait">
                                <a href="<?php echo e($salon->imagePath); ?><?php echo e($salon->image); ?>" class="fs-slider-item d-block photo img-box-item"
                                    style="background-image:url(<?php echo e($salon->imagePath); ?><?php echo e($salon->image); ?>)" data-fancybox="gallery">
                               </a><!-- end fs-slider-item -->
                                <?php $__currentLoopData = $salon->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e($item->imagePath); ?><?php echo e($item->image); ?>" class="fs-slider-item d-block photo img-box-item"
                                         style="background-image:url(<?php echo e($item->imagePath); ?><?php echo e($item->image); ?>)" data-fancybox="gallery">
                                    </a><!-- end fs-slider-item -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div><!-- end card-image -->
                    </div><!-- end sidebar-widget -->
                    <div class="sidebar-widget">
                        <h3 class="widget-title"> <?php echo e(__('layout.Salon Owner')); ?> </h3>
                         <div class="stroke-shape mb-4"></div>
                        <div class="hosted-by d-flex align-items-center">
                            <a href="user-profile.html" class="user-thumb user-thumb-md flex-shrink-0 mr-3">
                                <img src=" <?php echo e(url($salon->ownerDetails->imagePath .'/'.$salon->ownerDetails->image)); ?> " alt="author-img">
                            </a>
                            <div>
                                <h4 class="font-size-18"><a href="user-profile.html" class="text-color"> <?php echo e($salon->ownerDetails->name); ?> </a></h4>
                                <span class="font-size-13 text-gray font-weight-medium d-block line-height-22"> <?php echo e($salon->serviceCount); ?> <?php echo e(__('layout.Services')); ?> </span>
                            </div>
                        </div>
                         <ul class="list-items py-4">
                             <li><i class="la la-phone mr-2 text-color-2 font-size-18"></i><a href="tel:<?php echo e($salon->ownerDetails->phone); ?>" class="before-none"><?php echo e($salon->ownerDetails->code); ?><?php echo e($salon->ownerDetails->phone); ?></a></li>
                             <li><i class="la la-envelope mr-2 text-color-2 font-size-18"></i><a href="mailto:<?php echo e($salon->ownerDetails->email); ?>" class="before-none"> <?php echo e($salon->ownerDetails->email); ?> </a></li>
                         </ul>
                    </div><!-- end sidebar-widget -->
                   
                </div><!-- end sidebar -->
            </div><!-- end col-lg-4 -->
        </div>
        
        <div class="row">
            <div class="col-lg-12">
                <div class="listing-detail-wrap">
                    <div class="block-card mb-4">
                        <div class="block-card-header">
                            <h2 class="widget-title"><?php echo e(__('layout.Reviews')); ?> <span class="ml-1 text-color-2"> (<?php echo e($salon->rateCount); ?>) </span></h2>
                            <div class="stroke-shape"></div>
                        </div><!-- end block-card-header -->
                        <div class="block-card-body">
                             <div class="comments-list">
                                <?php echo $__env->make('website.pages.review', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                             </div>
                            <?php if($salon->review->total() >= 3): ?>
                                <button class="theme-btn border-0 gradient-btn" id="load-more">
                                    <?php echo e(__('layout.View More')); ?>

                                </button>
                            <?php endif; ?>
                        </div><!-- end block-card-body -->
                        
                    </div><!-- end block-card -->
                </div>
            </div>
        </div>
    </div><!-- end container -->
</section><!-- end listing-detail-area -->
<!-- ================================
    END LISTING DETAIL  AREA
================================= -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js" integrity="sha512-uURl+ZXMBrF4AwGaWmEetzrd+J5/8NRkWAvJx5sbPSSuOb0bZLqf+tOzniObO00BjHa/dD7gub9oCGMLPQHtQA==" crossorigin="anonymous"></script>
<script>
      $('[data-fancybox]').fancybox();
</script>

<?php $mapkey = \App\AdminSetting::find(1)->mapkey; ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($mapkey); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/website/pages/singleSalon.blade.php ENDPATH**/ ?>