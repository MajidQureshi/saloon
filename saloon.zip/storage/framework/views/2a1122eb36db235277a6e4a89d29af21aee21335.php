<?php $__currentLoopData = $emps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="user-card checkbox p-0">
        <input type="hidden" name="emp-<?php echo e($item->emp_id); ?>" class="emp" value="<?php echo e($item->name); ?>">
        <label class="checkbox-wrapper">
            <input type="radio" name="emp_id" class="checkbox-input wizard-required" value="<?php echo e($item->emp_id); ?>" <?php echo e($key == 0? 'checked':''); ?>/>
            <div class="user-bio">
                <div class="d-flex align-items-center">
                    <div class="user-thumb user-thumb-md mr-3">
                        <img src="<?php echo e($item->imagePath .'/'. $item->image); ?> " alt="author-image">
                    </div>
                    <div class="user-inner-bio">
                        <h4 class="author__title"> <?php echo e($item->name); ?> </h4>
                    </div>
                </div>
            </div>
        </label>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\xampp\htdocs\SmartCitaHome\resources\views/website/pages/empList.blade.php ENDPATH**/ ?>