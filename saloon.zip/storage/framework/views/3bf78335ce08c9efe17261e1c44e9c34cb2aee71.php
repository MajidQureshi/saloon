
<?php $__env->startSection('website_content'); ?>
<?php echo $__env->make('website.layouts.breadcrumb', [
    'title' => __('All Salons'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- ================================
    START CARD AREA
================================= -->
<section class="card-area section-padding">
    <div class="container">
        <form action="#" method="POST">
            <div class="row">
                <div class="col-lg-12">
                    <div class="filter-bar d-flex flex-wrap justify-content-between align-items-center margin-bottom-30px">
                        <p class="result-text font-weight-medium" id="salon_found"> <?php echo e(count($salons)); ?> Salons Found </p>
                        <div class="filter-bar-action d-flex flex-wrap align-items-center">
                            <div class="user-chosen-select-container ml-3">
                                <select class="user-chosen-select" name="sort" id="sort">
                                    <option value="sort-by-default"><?php echo e(__('layout.Sort by default')); ?></option>
                                    <option value="high-rated"><?php echo e(__('layout.High Rated')); ?></option>
                                    <option value="most-reviewed"><?php echo e(__('layout.Most Reviewed')); ?></option>
                                    <option value="popular-salons"><?php echo e(__('layout.Popular Salons')); ?></option>
                                    <option value="newest-salons"><?php echo e(__('layout.Newest Salons')); ?></option>
                                    <option value="older-salons"><?php echo e(__('layout.Older Salons')); ?></option>
                                </select>
                            </div>
                            
                            <ul class="filter-nav ml-1">
                                <input type="hidden" name="view" id="view" value="Grid">
                                <li>
                                    <div data-toggle="tooltip" data-placement="top" title="Grid View" class="active" id="grid"><span class="la la-th-large"></span></div>
                                </li>
                                <li>
                                    <div data-toggle="tooltip" data-placement="top" title="List View" class="" id="list"><span class="la la-list"></span></div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="sidebar mt-0">
                        <div class="sidebar-widget">
                            <h3 class="widget-title"><?php echo e(__('layout.Search')); ?></h3>
                            <div class="stroke-shape mb-4"></div>
                            <div class="form-box">
                                <div class="form-group">
                                    <span class="la la-search form-icon"></span>
                                    <input class="form-control" type="search" id="look_for" value="<?php echo e($requests['look_for']); ?>" name="look_for" placeholder="What are you looking for?">
                                </div>
                                <div class="form-group search-location">
                                    <span class="la la-map-marker form-icon"></span>
                                    <input class="form-control" type="search" id="search_address" value="<?php echo e($requests['location']); ?>" name="location" placeholder="Search a Location">
                                </div>
                                <div class="form-group user-chosen-select-container">
                                    <select class="user-chosen-select" name="category" id="category" data-default="0">
                                        <option value="0" selected="selected" ><?php echo e(__('layout.Select a Category')); ?></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->cat_id); ?>" <?php echo e($requests["category"] == $cat->cat_id ? 'selected': ''); ?>> <?php echo e($cat->name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div><!-- end form-group -->
                                <input type="hidden" name="lat" id="lat" value="<?php echo e($requests['lat']); ?>">
                                <input type="hidden" name="lang" id="lang" value="<?php echo e($requests['lang']); ?>">
                                <div class="btn-box">
                                    <input type="hidden" value="" name="open" id="isopen">
                                    <button class="btn-gray btn-gray-lg open-filter-btn w-100"><i class="la la-clock mr-2"></i><?php echo e(__('layout.Now Open')); ?></button>
                                    <button type="button" class="theme-btn gradient-btn border-0 w-100 mt-3" id="search-btn">
                                        <i class="la la-search mr-2"></i><?php echo e(__('layout.Search Now')); ?>

                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="sidebar-widget">
                            <h3 class="widget-title"><?php echo e(__('layout.Filter by Salon Type')); ?></h3>
                            <div class="stroke-shape mb-4"></div>
                            <ul class="custom-radio">
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="salon_type" value="Male">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="font-weight-medium">
                                            <?php echo e(__('layout.Male')); ?>

                                        </div>
                                    </div>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="salon_type" value="Female">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="font-weight-medium">
                                            <?php echo e(__('layout.Female')); ?>

                                        </div>
                                    </div>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="salon_type" value="All" checked="checked">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="font-weight-medium">
                                            <?php echo e(__('layout.All')); ?>

                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="sidebar-widget">
                            <h3 class="widget-title"><?php echo e(__('layout.Filter by Service Place')); ?></h3>
                            <div class="stroke-shape mb-4"></div>
                            <ul class="custom-radio">
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="service_place" value="Salon">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="font-weight-medium">
                                            <?php echo e(__('layout.Salon')); ?>

                                        </div>
                                    </div>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="service_place" value="Home">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="font-weight-medium">
                                            <?php echo e(__('layout.Home')); ?>

                                        </div>
                                    </div>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="service_place" value="Both" checked="checked">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="font-weight-medium">
                                            <?php echo e(__('layout.Both')); ?>

                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="sidebar-widget">
                            <h3 class="widget-title"><?php echo e(__('layout.Filter by Ratings')); ?></h3>
                            <div class="stroke-shape mb-4"></div>
                            <ul class="custom-radio">
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="rate" value="all" checked="checked">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="font-weight-medium">
                                            <?php echo e(__('layout.Show All')); ?>

                                        </div>
                                    </div>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="rate" value="5">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="stars">
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                        </div>
                                    </div>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="rate" value="4">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="stars">
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                            <span class="la la-star-o text-gray"></span>
                                        </div>
                                    </div>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="rate" value="3">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="stars">
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                            <span class="la la-star-o text-gray"></span>
                                            <span class="la la-star-o text-gray"></span>
                                        </div>
                                    </div>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="rate" value="2">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="stars">
                                            <span class="la la-star"></span>
                                            <span class="la la-star"></span>
                                            <span class="la la-star-o text-gray"></span>
                                            <span class="la la-star-o text-gray"></span>
                                            <span class="la la-star-o text-gray"></span>
                                        </div>
                                    </div>
                                </li>
                                <li class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <label class="radio-label">
                                            <input type="radio" name="rate" value="1">
                                            <span class="radio-mark"></span>
                                        </label>
                                        <div class="stars">
                                            <span class="la la-star"></span>
                                            <span class="la la-star-o text-gray"></span>
                                            <span class="la la-star-o text-gray"></span>
                                            <span class="la la-star-o text-gray"></span>
                                            <span class="la la-star-o text-gray"></span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="sidebar-widget col-lg-12">
                            <div class="btn-box">
                                <button type="button" class="theme-btn gradient-btn w-100 border-0" id="apply_filter">
                                    <?php echo e(__('layout.Apply Filter')); ?> <i class="la la-arrow-right ml-1"></i>
                                </button>
                                <button type="reset" class="btn-gray btn-gray-lg mt-3 w-100" id="reset-btn">
                                    <i class="la la-redo-alt mr-1"></i> <?php echo e(__('layout.Reset Filters')); ?>

                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="row" id="salon-list">
                        <?php if($include == "Grid"): ?>
                            <?php echo $__env->make('website.pages.allSalonGrid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php else: ?>
                            <?php echo $__env->make('website.pages.allSalonList', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>
<!-- ================================
    END CARD AREA
================================= -->

<?php $mapkey = \App\AdminSetting::find(1)->mapkey; ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($mapkey); ?>&libraries=places&callback=initAutocomplete"  defer></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\SmartCitaHome\resources\views/website/pages/allSalon.blade.php ENDPATH**/ ?>