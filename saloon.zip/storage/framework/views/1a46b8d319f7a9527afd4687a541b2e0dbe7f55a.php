
<?php $__env->startSection('content'); ?>

    <section class="main-area">
        <div class="container-fluid">
            <div class="row h100">
                <?php $bg_img = \App\AdminSetting::find(1)->bg_img; ?>
                <div class="col-md-6 p-0 m-none" style="background: url(<?php echo e(asset('storage/images/app/'.$bg_img)); ?>) center center;background-size: cover;background-repeat: no-repeat;">
                    <span class="mask bg-gradient-dark opacity-6"></span>
                </div>

                <div class="col-md-6 p-0 data-box-col">
                    <div class="login">
                        <div class="center-box">
                            
                            <div class="title">
                                <h4 class="login_head"><?php echo e(__('Owner Login')); ?></h4>
                                <p class="login-para"><?php echo e(__('This is a secure system and you will need to provide your')); ?> <br>
                                    <?php echo e(__('login details to access the site.')); ?></p>
                            </div>
                            <div class="form-wrap">
                                <form role="form"  class="pui-form" id="loginform"  method="POST" action="<?php echo e(url('/owner/login/done')); ?>">
                                <?php echo csrf_field(); ?>
                                    <div class="pui-form__element">
                                        <label class="animated-label <?php echo e(old('email') != null ? 'moveUp': ''); ?>"><?php echo e(__('Email')); ?></label>
                                        <input id="inputEmail" type="email" class="form-control  <?php echo e(old('email') != null ? 'outline': ''); ?> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="" autocomplete="email">
                                            
                                    </div>
                                    <div class="pui-form__element">
                                        <label class="animated-label"><?php echo e(__('Password')); ?></label>
                                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="" autocomplete="current-password">
                                            
                                    </div>
                                    <?php if($errors->any()): ?>
                                        <h4 class="text-center text-red"><?php echo e($errors->first()); ?></h4>
                                    <?php endif; ?>
                                    
                                    <div class="form-check">

                                        <label class="form-check-label forget-password" for="exampleCheck1">
                                            <a href="<?php echo e(url('/owner/forgetpassword')); ?>"><?php echo e(__('Forgot password?')); ?></a>
                                        </label>
                                    </div>
                                    <div class="pui-form__element">
                                        <button class="btn btn-lg btn-primary btn-block btn-salon" type="submit"><?php echo e(__('SIGN IN')); ?></button>
                                    </div>
                                </form>
                                <span class="signup-label"><?php echo e(__("Don't have an account??")); ?> <a href="<?php echo e(url('/owner/register')); ?>"> <?php echo e(__('Create Now.')); ?> </a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/owner/login/login.blade.php ENDPATH**/ ?>