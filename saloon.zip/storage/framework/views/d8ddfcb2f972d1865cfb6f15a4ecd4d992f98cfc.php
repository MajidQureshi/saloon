<?php $__currentLoopData = $salons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card-item card-item-list">
        <div class="card-image">
            <a href="<?php echo e(url('salon/'.$salon['salon_id']. '/'. Str::slug($salon['name']))); ?>" class="d-block">
                <img src="<?php echo e($salon['imagePath'] .'/'. $salon['image']); ?>" class="card__img" alt="">
                <?php if($salon['open']): ?>
                    <span class="badge"> <?php echo e(__('layout.Open')); ?> </span>
                <?php else: ?>
                    <span class="badge bg-11"> <?php echo e(__('layout.Close')); ?> </span>
                <?php endif; ?>
                
            </a>
        </div>
        <div class="card-content">
            <a href="#" class="user-thumb d-inline-block" data-toggle="tooltip" data-placement="top" title="<?php echo e($salon['name']); ?>"">
                <img src="<?php echo e($salon['imagePath'] .'/'. $salon['logo']); ?>" alt="author-img">
            </a>
            <h4 class="card-title pt-3">
                <a href="<?php echo e(url('salon/'.$salon['salon_id']. '/'. Str::slug($salon['name']))); ?>"><?php echo e($salon['name']); ?></a>
            </h4>
            <p class="card-sub"><?php echo e(substr($salon['desc'],0,80)); ?> <?php echo e(strlen($salon['desc']) > 80 ? '...' : ""); ?></p>
            <ul class="listing-meta d-flex align-items-center">
                <li class="d-flex align-items-center">
                    <span class="rate flex-shrink-0"> <?php echo e($salon['rate']); ?> </span>
                    <span class="rate-text"> <?php echo e($salon['rateCount']); ?> <?php echo e(__('layout.Ratings')); ?></span>
                </li>
                <li class="mx-4">
                    <?php if($salon['give_service'] == "Salon"): ?>
                        <i class="la la-at listing-icon text-color-2"></i> <?php echo e(__('layout.Salon')); ?>

                    <?php elseif($salon['give_service'] == "Home"): ?>
                        <i class="la la-at listing-icon text-color-2"></i> <?php echo e(__('layout.Home')); ?>

                    <?php else: ?>
                        <i class="la la-at listing-icon text-color-2"></i> <?php echo e(__('layout.Both')); ?>

                    <?php endif; ?>
                </li>
                <li class="d-flex align-items-center">
                    <?php if($salon['gender'] == "Male"): ?>
                        <i class="la la-mars mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Male')); ?>

                    <?php elseif($salon['gender'] == "Female"): ?>
                        <i class="la la-venus mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Female')); ?>

                    <?php else: ?>
                        <i class="la la-venus-mars mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Unisex')); ?>

                    <?php endif; ?>
                </li>
            </ul>
            <ul class="info-list padding-top-20px">
                <li><span class="la la-map-marker mr-2 icon"></span>
                    <?php echo e($salon['city']); ?>, <?php echo e($salon['state']); ?>, <?php echo e($salon['country']); ?>

                </li>
                <li><span class="la la-phone mr-2 icon"></span>
                    <?php echo e($salon['phone']); ?>

                </li>
            </ul>
        </div>
    </div><!-- end card-item -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\xampp\htdocs\SmartCitaHome\resources\views/website/pages/allSalonList.blade.php ENDPATH**/ ?>