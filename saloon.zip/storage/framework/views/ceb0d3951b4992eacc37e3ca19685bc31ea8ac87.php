<?php $__currentLoopData = $salon->review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="comment">
        <div class="user-thumb user-thumb-lg flex-shrink-0">
            <img src="<?php echo e($review->user->imagePath.'/'.$review->user->image); ?>" alt="author-img">
        </div>
        <div class="comment-body w-100">
            <div class="meta-data d-flex align-items-center justify-content-between">
                <div>
                    <h4 class="comment__title"> <?php echo e($review->user->name); ?> </h4>
                </div>
                <div class="star-rating-wrap text-center mt-1">
                    <div class="star-rating text-color-5 font-size-18">
                        <?php
                            $rating = $review->rate;
                        ?>
                        <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rating >0): ?>
                                <?php if($rating >0.5): ?>
                                    <span class="ml-n1"><i class="la la-star"></i></span>
                                <?php endif; ?>
                            <?php else: ?> 
                                <span class="ml-n1"><i class="la la-star-o"></i></span>
                            <?php endif; ?>
                            <?php $rating--; ?>
                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <p class="font-size-13 font-weight-medium"> <?php echo e(\Carbon\Carbon::parse($review->created_at)->format('Y-m-d')); ?> </p>
                </div>
            </div>
            <p class="comment-desc">
                <?php echo e($review->message); ?>

            </p>
        </div>
    </div><!-- end comment -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/website/pages/review.blade.php ENDPATH**/ ?>