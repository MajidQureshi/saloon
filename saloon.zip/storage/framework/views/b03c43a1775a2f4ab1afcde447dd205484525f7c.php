
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.top-header', [
'title' => __('Subscription'),
'class' => 'col-lg-7'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--6 mb-5">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <span class="h3"><?php echo e(__('Subscription table')); ?></span>
                    <button class="btn btn-primary addbtn float-right p-2 add_subscription" id="add_subscription"><i
                            class="fas fa-plus mr-1"></i><?php echo e(__('Add New')); ?></button>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush" id="dataTable">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col" class="sort"><?php echo e(__('#')); ?></th>
                                <th scope="col" class="sort"><?php echo e(__('Name')); ?></th>
                                <th scope="col" class="sort"><?php echo e(__('Description')); ?></th>
                                <th scope="col" class="sort"><?php echo e(__('Old Price')); ?></th>
                                <th scope="col" class="sort"><?php echo e(__('New Price')); ?></th>
                                <th scope="col" class="sort"><?php echo e(__('Status')); ?></th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php if(count($subscriptions) != 0): ?>
                            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($loop->iteration); ?> </th>
                                <td><?php echo e($subscription->name); ?></td>
                                <td><?php echo e($subscription->description); ?></td>
                                <td><?php echo e($subscription->old_price); ?></td>
                                <td><?php echo e($subscription->new_price); ?></td>

                                <td>
                                    <label class="custom-toggle">
                                        <input type="checkbox" onchange="hideSubscription(<?php echo e($subscription->id); ?>)"
                                            <?php echo e($subscription->status == 0?'checked': ''); ?>>
                                        <span class="custom-toggle-slider rounded-circle" data-label-off="No"
                                            data-label-on="Hide"></span>
                                    </label>
                                </td>
                                <td class="table-actions">
                                    <?php
                                    $base_url = url('/');
                                    ?>

                                    <button class="btn-white btn shadow-none p-0 m-0 table-action text-warning bg-white"
                                        onclick="show_sub_features(<?php echo e($subscription->id); ?>,'<?php echo e($base_url); ?>')"
                                        data-toggle="tooltip" data-original-title="<?php echo e(__('Features')); ?>">
                                        <i class="fas fa-list"></i>
                                    </button>

                                    <button class="btn-white btn shadow-none p-0 m-0 table-action text-info bg-white"
                                        onclick="edit_subscription(<?php echo e($subscription->id); ?>,'<?php echo e($base_url); ?>')"
                                        data-toggle="tooltip" data-original-title="<?php echo e(__('Edit Subscription')); ?>">
                                        <i class="fas fa-user-edit"></i>
                                    </button>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <th colspan="10" class="text-center"><?php echo e(__('No Subscriptions')); ?></th>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin.subscription.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.subscription.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.subscription.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/admin/pages/subscription.blade.php ENDPATH**/ ?>