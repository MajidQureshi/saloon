<?php $bg_img = \App\AdminSetting::find(1)->bg_img; ?>
<div class="header pt-7" style="background-image: url(<?php echo e(asset('storage/images/app/'.$bg_img)); ?>); background-size: cover; background-position: center center;">
    <span class="mask bg-gradient-dark opacity-7"></span>
    <div class="container-fluid">
      <div class="header-body">
        <div class="row align-items-center py-4 pb-7">
          <div class="col-lg-6 col-7">
            <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
              <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                <?php if(Auth::user()->role == 2): ?>
                    <li class="breadcrumb-item text-white"><a href="<?php echo e(url('owner/dashboard')); ?>"><i class="fas fa-home text-salon"></i></a></li>
                <?php elseif(Auth::user()->role == 1): ?>
                    <li class="breadcrumb-item text-white"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fas fa-home text-salon"></i></a></li>
                <?php endif; ?>
                <?php if(isset($headerData) && $headerData): ?>
                    <li class="breadcrumb-item text-white"><a href="<?php echo e(url($url)); ?>" class="text-salon"><?php echo e($headerData); ?></a></li>
                <?php endif; ?>
                <li class="breadcrumb-item active text-white" aria-current="page">&nbsp;<?php echo e($title); ?> </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/layouts/top-header.blade.php ENDPATH**/ ?>