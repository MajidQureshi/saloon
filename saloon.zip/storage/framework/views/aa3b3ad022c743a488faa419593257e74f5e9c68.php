<nav class="nav container">
    <div class="nav__logo">
        <img src="<?php echo e(asset('html-assests/shared/logo.png')); ?>" alt="Meetendo logo" class="nav__logo__img" />
        <h2 class="nav__logo__title">Meetendo</h2>
    </div>
    <ul class="nav__list">
        <a href="<?php echo e(url('/')); ?>">
            <li class="nav__list__item">Home</li>
        </a>
        <a href="<?php echo e(url('/pricing')); ?>">
            <li class="nav__list__item">Pricing</li>
        </a>
        <a href="<?php echo e(url('/support')); ?>">
            <li class="nav__list__item">Support</li>
        </a>
    </ul>

    <div class="nav__login">
    <?php if(Auth::check()): ?>
    
    <div class="dropdown">
        <button class="dropbtn"><?php echo e(Auth::user()->name); ?></button>
        <div class="dropdown-content">
            <a href="<?php echo e(url('/profile')); ?>">Profile</a>
            <a href="<?php echo e(url('/appointments')); ?>">Booking</a>
            <a href="<?php echo e(url('/logout')); ?>" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">Logout</a>
            <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
        </div>
    </div>
    
    <?php else: ?>
    <!-- <a class="nav__login__link" href="<?php echo e(url('/login')); ?>">Log in</a> -->
    <div class="dropdown">
        <a class="nav__login__link">Log in</a>
            <div class="dropdown-content">
                <a href="<?php echo e(url('/login')); ?>">Individual Login</a>
                <a href="<?php echo e(url('/owner/login')); ?>">Business Login</a>
            </div>
    </div>
    <?php endif; ?>
        
        <button class="nav__login__button">
            <a href="<?php echo e(url('/pricing')); ?>">Subscribe Now</a>
        </button>
    </div>
    <img class="nav__menu" src="<?php echo e(asset('html-assests/shared/menu.svg')); ?>" alt="" />
</nav><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/website/layouts/header-1.blade.php ENDPATH**/ ?>