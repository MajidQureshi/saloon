<div class="container-fluid sidebar_open <?php if($errors->any()): ?> show_sidebar_create <?php endif; ?>" id="add_user_sidebar">
    <div class="row">
        <div class="col">
            <div class="card py-3 border-0">
                <div class="border_bottom_pink pb-3 pt-2 mb-4">
                    <span class="h3"><?php echo e(__('Create Client')); ?></span>
                    <button type="button" class="add_user close">&times;</button>
                </div>
                <form class="form-horizontal"  id="create_user_form" method="post" enctype="multipart/form-data" action="<?php echo e(url('/owner/users')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="my-0">
                    <?php $is_point_package = config('point.active'); ?>

                        <?php if($is_point_package == 1): ?>
                            <?php
                                $permitted_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                                $code = substr(str_shuffle($permitted_chars), 0, 6);
                            ?>
                            <div class="form-group">
                                <label class="form-control-label" for="referral_code"><?php echo e(__('Your reference code')); ?></label>
                                <input type="text" name="referral_code" value="<?php echo e($code); ?>" id="referral_code" class="form-control" readonly>
                                <div class="invalid-div "><span class="referral_code"></span></div>
                            </div>
                          
                            <div class="form-group">
                                <label class="form-control-label" for="friend_code"><?php echo e(__('Referral code')); ?></label>
                                <input type="text" name="friend_code" value="<?php echo e(old('friend_code')); ?>" id="friend_code" class="form-control" placeholder="<?php echo e(__('Referral code')); ?>" autofocus>
                                <div class="invalid-div "><span class="friend_code"></span></div>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label class="form-control-label" for="name"><?php echo e(__('Name')); ?></label>
                            <input type="text" name="name" value="<?php echo e(old('name')); ?>" id="name" class="form-control" placeholder="<?php echo e(__('User name')); ?>" autofocus>
                            <div class="invalid-div "><span class="name"></span></div>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label" for="email"><?php echo e(__('Email')); ?></label><br>
                            <input type="text" name="email" value="<?php echo e(old('email')); ?>"  id="email" class="form-control" placeholder="<?php echo e(__('Email Address')); ?>" autocomplete="email">
                            <div class="invalid-div "><span class="email"></span></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-control-label" for="password"><?php echo e(__('Password')); ?></label>
                            <input type="password" name="password"  id="password" class="form-control" placeholder="<?php echo e(__('Password')); ?>" autocomplete="current-password">
                            <div class="invalid-div "><span class="password"></span></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-control-label" for="code"><?php echo e(__('Country Code')); ?></label><br>
                            <input type="number" min="1" name="code" value="<?php echo e(old('code')); ?>"  id="code" class="form-control" placeholder="<?php echo e(__('Country Code')); ?>">
                            <div class="invalid-div "><span class="code"></span></div>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label" for="phone"><?php echo e(__('Phone no.')); ?></label><br>
                            <input type="text" name="phone" maxlength="10" value="<?php echo e(old('phone')); ?>"  id="phone" class="form-control" placeholder="<?php echo e(__('Phone number')); ?>">
                            <div class="invalid-div "><span class="phone"></span></div>
                        </div>

                        <div class="text-center">
                            <button type="button" id="create_btn" onclick="all_create('create_user_form','users')" class="btn btn-primary mt-4 mb-5 rtl-float-none"><?php echo e(__('Create')); ?></button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/owner/user/create.blade.php ENDPATH**/ ?>