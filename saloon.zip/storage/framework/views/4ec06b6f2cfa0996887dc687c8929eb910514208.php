
<?php $__env->startSection('website_content'); ?>
<?php echo $__env->make('website.layouts.breadcrumb', [
    'title' => __('All Categories'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- ================================
    START CATEGORY AREA
================================= -->
<section class="category-area section--padding">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 responsive-column">
                    <div class="category-item overflow-hidden">
                        <img src="<?php echo e(url($item->imagePath .'/'. $item->banner)); ?>" alt="category-image" class="cat-img">
                        <div class="category-content d-flex align-items-center justify-content-center">
                            
                                <a href="<?php echo e(url('/all-salons?category='.$item->cat_id)); ?>" class="category-link d-flex flex-column justify-content-center w-100 h-100">
                                <div class="icon-element mb-3 mx-auto">
                                    <img src="<?php echo e(url($item->imagePath .'/'. $item->image)); ?>" alt="">
                                </div>
                                <div class="cat-content">
                                    <h4 class="cat__title mb-3"> <?php echo e($item->name); ?> </h4>
                                    <span class="badge"> <?php echo e($item->salonCount); ?> <?php echo e($item->salonCount > 1? __('layout.Salons') : __('layout.Salon')); ?>  </span>
                                </div>
                            </a>
                        </div>
                    </div><!-- end category-item -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><!-- end row -->
    </div><!-- end container -->
</section><!-- end category-area -->
<!-- ================================
    END CATEGORY AREA
================================= -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/website/pages/allCat.blade.php ENDPATH**/ ?>