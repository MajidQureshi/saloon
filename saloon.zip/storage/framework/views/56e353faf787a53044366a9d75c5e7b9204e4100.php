
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.top-header', [
        'title' => __('Clients'),
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--6 mb-5 only_search">
    <div class="row">
      <div class="col">
        <div class="card">
          <div class="card-header border-0">
            <span class="h3"><?php echo e(__('Users table')); ?></span>
            <button class="btn btn-primary addbtn float-right p-2 add_user" id="add_user"><i class="fas fa-plus mr-1"></i><?php echo e(__('Add New')); ?></button>
          </div>
          
          <form action="<?php echo e(url('/owner/users')); ?>" method="post" class="ml-4" id="filter_revene_form">
            <?php echo csrf_field(); ?>
            <div class="row rtl-date-filter-row">
                <div class="form-group col-3">
                    <input type="text" id="filter_date" value="<?php echo e($pass); ?>" name="filter_date" class="form-control" placeholder="<?php echo e(__('-- Select Date --')); ?>">
                
                    <?php if($errors->any()): ?>
                        <h4 class="text-center text-red mt-2"><?php echo e($errors->first()); ?></h4>
                    <?php endif; ?>
                </div>
                <div class="form-group col-3">
                    <button type="submit" id="filter_btn" class="btn btn-primary  rtl-date-filter-btn"><?php echo e(__('Apply')); ?></button>
                </div>
            </div>
        </form>

          <div class="table-responsive">
            <table class="table align-items-center table-flush" id="dataTableUser" class="dataTableUser">
              <thead class="thead-light">
                <tr>
                    <th scope="col" class="sort"><?php echo e(__('#')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Image')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Name')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Email')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Created_at')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Updated_at')); ?></th>
                    <th scope="col"></th>
                </tr>
              </thead>
              <tbody class="list">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td>
                                <img alt="Image placeholder" class="tableimage rounded" src="<?php echo e(asset('storage/images/users/'.$user->image)); ?>">
                            </td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->created_at); ?></td>
                            <td><?php echo e($user->updated_at); ?></td>
                            <td class="table-actions">
                                <a href="<?php echo e(url('owner/users/'.$user->id)); ?>" class="table-action text-warning" data-toggle="tooltip" data-original-title="<?php echo e(__('View client')); ?>">
                                    <i class="fas fa-eye"></i>
                                </a>
                          </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
</div>

<?php echo $__env->make('owner.user.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/owner/pages/user.blade.php ENDPATH**/ ?>