<!DOCTYPE html>
<html lang="en">

<head>
    <?php $app_name = \App\AdminSetting::find(1)->app_name; ?>
    <title> <?php echo e($app_name); ?> </title>
    
    <?php $favicon = \App\AdminSetting::find(1)->favicon; ?>
    <link href="<?php echo e(asset('storage/images/app/'.$favicon)); ?>" rel="icon" type="image/png">

    <?php $color = \App\AdminSetting::find(1)->color; ?>
    <style>
        :root{
            --primary_color : <?php echo $color ?>;
            --primary_color_hover : <?php echo $color.'cc' ?>;
        }
    </style>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.21/b-1.6.2/b-flash-1.6.2/b-html5-1.6.2/b-print-1.6.2/datatables.min.css" />
    <link href="<?php echo e(asset('includes/css/nucleo.css')); ?>" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('includes/css/jquery.timepicker.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('includes/css/argon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('includes/css/mystyle.css')); ?>" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <?php if(session('direction') == "rtl"): ?>
        <link href="<?php echo e(asset('includes/css/rtl.css')); ?>" rel="stylesheet">
    <?php endif; ?>
</head>

<body class="login">

    <section class="main-area">
        <div class="container-fluid">
            <div class="row h100">
                <?php $bg_img = \App\AdminSetting::find(1)->bg_img; ?>

                <div class="col-md-12 p-0">
                    <div class="card bg-secondary border-0 mb-0">
                        <div class="card-header bg-transparent pb-5">
                            <h1 class="text-center"><?php echo e(__('Add Your Salon')); ?></h1>
                            <div class="mx-4">
                                <div class="nav-wrapper wizard">
                                    <ul class="nav nav-pills nav-fill flex-column flex-md-row nav-wizard" id="tabs-icons-text" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link mb-sm-3 mb-md-0 active" id="tabs-icons-text-1-tab" data-toggle="tab" href="#tabs-icons-text-1" role="tab" aria-controls="tabs-icons-text-1" aria-selected="true"><i class="ni ni-scissors mr-2"></i><?php echo e(__('Salon')); ?></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link mb-sm-3 mb-md-0" id="tabs-icons-text-2-tab" data-toggle="tab" href="#tabs-icons-text-2" role="tab" aria-controls="tabs-icons-text-2" aria-selected="false"><i class="ni ni-time-alarm mr-2"></i><?php echo e(__('Timing')); ?></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link mb-sm-3 mb-md-0" id="tabs-icons-text-3-tab" data-toggle="tab" href="#tabs-icons-text-3" role="tab" aria-controls="tabs-icons-text-3" aria-selected="false"><i class="ni ni-square-pin mr-2"></i><?php echo e(__('Location')); ?></a>
                                        </li>
                                    </ul>
                                </div>
                                <?php if(count($errors) > 0): ?>
                                    <div class="alert alert-danger">
                                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <form class="form-horizontal form" action="<?php echo e(url('/owner/salons/store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                    <div class="card shadow mx-auto">
                                        <div class="card-body">
                                            <div class="tab-content" id="myTabContent">
                                                <div class="tab-pane fade show active wizard-pane" id="tabs-icons-text-1" role="tabpanel" aria-labelledby="tabs-icons-text-1-tab">
                                                    <div class="p-20">
                                                        <div class="row">

                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label class="form-control-label" for="name"><?php echo e(__('Name')); ?></label>
                                                                <input type="text" value="<?php echo e(old('name')); ?>" name="name" id="name" class="form-control" placeholder="<?php echo e(__('name should be match with license')); ?>"  autofocus>
                                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>

                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label class="form-control-label" for="license_image"><?php echo e(__('License Image')); ?></label><br>
                                                                <input type="file"  value="<?php echo e(old('license_image')); ?>" id="license_image" name="license_image" accept="image/*" onchange="loadFile6(event)" ><br>
                                                                <img id="license_image_output" class="uploadsalonimg mt-3"/>
                                                                <?php $__errorArgs = ['license_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>

                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label class="form-control-label" for="id_card"><?php echo e(__('ID Card')); ?></label><br>
                                                                <input type="file"  value="<?php echo e(old('id_card')); ?>" id="id_card" name="id_card" accept="image/*" onchange="loadFile5(event)" ><br>
                                                                <img id="id_card_output" class="uploadsalonimg mt-3"/>
                                                                <?php $__errorArgs = ['id_card'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                
                                
                                            
                                                        <div class="col-md-4">
                                                                
                                                                <div class="form-group col-6">
                                                                    <label class="form-control-label"><?php echo e(__('Salon for')); ?></label><br>
                                                                    <div class="custom-control custom-radio mb-2">
                                                                        <input type="radio" id="male" name="gender" value="Male" class="custom-control-input">
                                                                        <label class="custom-control-label" for="male"><?php echo e(__('Male')); ?></label>
                                                                    </div>
                                                                    <div class="custom-control custom-radio mb-2">
                                                                        <input type="radio" id="female" name="gender" value="Female" class="custom-control-input">
                                                                        <label class="custom-control-label" for="female"><?php echo e(__('Female')); ?></label>
                                                                    </div>
                                                                    <div class="custom-control custom-radio mb-2">
                                                                        <input type="radio" id="both" name="gender" value="Both" class="custom-control-input" checked>
                                                                        <label class="custom-control-label" for="both"><?php echo e(__('Both')); ?></label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                                
                                                            
                                                            <div class="col-md-4">
                                                                <div class="form-group col-6 give_service_class">
                                                                    <label class="form-control-label"><?php echo e(__('Give Services At')); ?></label><br>
                                                                    <div class="custom-control custom-radio mb-2">
                                                                        <input type="radio" id="salon" name="give_service" value="Salon" class="custom-control-input">
                                                                        <label class="custom-control-label" for="salon"><?php echo e(__('Salon')); ?></label>
                                                                    </div>
                                                                    <div class="custom-control custom-radio mb-2">
                                                                        <input type="radio" id="home" name="give_service" value="Home" class="custom-control-input">
                                                                        <label class="custom-control-label" for="home"><?php echo e(__('Home')); ?></label>
                                                                    </div>
                                                                    <div class="custom-control custom-radio mb-2">
                                                                        <input type="radio" id="both_service" name="give_service" value="Both" class="custom-control-input" checked>
                                                                        <label class="custom-control-label" for="both_service"><?php echo e(__('Both')); ?></label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        
                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group" id="home_charges_div">
                                                                <label for="home_charges" class="form-control-label"><?php echo e(__('Extra charge for home services')); ?></label>
                                                                <input type="number" value="<?php echo e(old('home_charges',0)); ?>" min="0"  class="form-control" name="home_charges" id="home_charges" placeholder="<?php echo e(__('Extra charge for home services')); ?>">
                                                                <?php $__errorArgs = ['home_charges'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>

                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group col-6 give_service_class">
                                                                <label class="form-control-label"><?php echo e(__('Do You Have Website ?')); ?></label><br>
                                                                <div class="custom-control custom-radio mb-2">
                                                                    <input type="radio" id="have_website" name="have_website" value="yes" class="custom-control-input">
                                                                    <label class="custom-control-label" for="have_website"><?php echo e(__('Yes')); ?></label>
                                                                </div>
                                                                <div class="custom-control custom-radio mb-2">
                                                                    <input type="radio" id="not_have_website" name="have_website" value="no" class="custom-control-input">
                                                                    <label class="custom-control-label" for="not_have_website"><?php echo e(__('No')); ?></label>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        
                                                        <div class="col-md-4 d-none" id="website_div">
                                                            <div class="form-group">
                                                                <label for="website" class="form-control-label"><?php echo e(__('Website Name')); ?></label>
                                                                <input type="text" value="<?php echo e(old('website')); ?>"  class="form-control" name="website" id="website" placeholder="<?php echo e(__('Website name')); ?>">
                                                                <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>

                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="phone" class="form-control-label"><?php echo e(__('Phone no')); ?></label>
                                                                <input type="number" maxlength="10" value="<?php echo e(old('phone', Auth::user()->phone)); ?>"  class="form-control" name="phone" id="phone" placeholder="<?php echo e(__('Phone Number')); ?>" >
                                                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>

                                                        
                                                        
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="desc" class="form-control-label"><?php echo e(__('Description')); ?></label>
                                                                <textarea class="form-control" rows="6" id="desc" name="desc" placeholder="<?php echo e(__('Description of salon')); ?>" ><?php echo e(old('desc')); ?></textarea>
                                                                <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="text-right">
                                                        <a href="#tabs-icons-text-2" data-toggle="tab" role="tab" aria-controls="tabs-icons-text-2" class="btn btn-primary btnNext">Next</a>
                                                    </div>
                                                </div>
                                                            
                                            </div>
                                                
                                                <div class="tab-pane fade" id="tabs-icons-text-2" role="tabpanel" aria-labelledby="tabs-icons-text-2-tab">
                                                    <div class="p-20">
                                                        <div class="row align-items-center mb-4">
                                                            <div class="col-5">
                                                                <div><?php echo e(__('Opening Time')); ?></div>
                                                            </div>
                                                            <div class="col-5">
                                                                <div><?php echo e(__('Closing Time')); ?></div>
                                                            </div>
                                                            <div class="col-2">
                                                                <div><?php echo e(__('Day Off')); ?></div>
                                                            </div>
                                                        </div>
                                                        <?php
                                                            $base_url = url('/');
                                                        ?>

                                                        

                                                        <label for="phone" class="form-control-label"><?php echo e(__('Sunday')); ?></label>
                                                        <div class="row align-items-center">
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('sunopen', '08:00')); ?>" class="form-control day-section-sunopen" name="sunopen" id="open">
                                                                    </div>
                                                                    <?php $__errorArgs = ['sunopen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('sunclose', '20:00')); ?>" class="form-control day-section-sunclose" name="sunclose" id="close">
                                                                    </div>
                                                                    <?php $__errorArgs = ['sunclose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-2">
                                                                <div class="form-group">
                                                                    <div class="custom-control custom-checkbox input-group check_center">
                                                                        <input type="checkbox" class="custom-control-input salonCheck" name="sun" value="sun" id="sun_check">
                                                                        <label class="custom-control-label" for="sun_check"></label>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <label for="phone" class="form-control-label"><?php echo e(__('Monday')); ?></label>
                                                        <div class="row align-items-center">
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('monopen','08:00')); ?>" class="form-control day-section-monopen" name="monopen" id="open">
                                                                    </div>
                                                                    <?php $__errorArgs = ['monopen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('monclose','20:00')); ?>" class="form-control day-section-monclose" name="monclose" id="close">
                                                                    </div>
                                                                    <?php $__errorArgs = ['monclose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-2">
                                                                <div class="form-group">
                                                                    <div class="custom-control custom-checkbox input-group check_center">
                                                                        <input type="checkbox" class="custom-control-input salonCheck" name="mon" value="mon" id="mon_check">
                                                                        <label class="custom-control-label" for="mon_check"></label>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <label for="phone" class="form-control-label"><?php echo e(__('Tuesday')); ?></label>
                                                        <div class="row align-items-center">
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('tueopen', '08:00')); ?>" class="form-control day-section-tueopen" name="tueopen" id="open">
                                                                    </div>
                                                                    <?php $__errorArgs = ['tueopen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('tueclose', '20:00')); ?>" class="form-control day-section-tueclose" name="tueclose" id="close">
                                                                    </div>
                                                                    <?php $__errorArgs = ['tueclose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-2">
                                                                <div class="form-group">
                                                                    <div class="custom-control custom-checkbox input-group check_center">
                                                                        <input type="checkbox" class="custom-control-input salonCheck" name="tue" value="tue" id="tue_check">
                                                                        <label class="custom-control-label" for="tue_check"></label>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <label for="phone" class="form-control-label"><?php echo e(__('Wednesday')); ?></label>
                                                        <div class="row align-items-center">
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('wedopen', '08:00')); ?>" class="form-control day-section-wedopen" name="wedopen" id="open">
                                                                    </div>
                                                                    <?php $__errorArgs = ['wedopen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('wedclose', '20:00')); ?>" class="form-control day-section-wedclose" name="wedclose" id="close">
                                                                    </div>
                                                                    <?php $__errorArgs = ['wedclose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-2">
                                                                <div class="form-group">
                                                                    <div class="custom-control custom-checkbox input-group check_center">
                                                                        <input type="checkbox" class="custom-control-input salonCheck" name="wed" value="wed" id="wed_check">
                                                                        <label class="custom-control-label" for="wed_check"></label>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <label for="phone" class="form-control-label"><?php echo e(__('Thursday')); ?></label>
                                                        <div class="row align-items-center">
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('thuopen', '08:00')); ?>" class="form-control day-section-thuopen" name="thuopen" id="open">
                                                                    </div>
                                                                    <?php $__errorArgs = ['thuopen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('thuclose', '20:00')); ?>" class="form-control day-section-thuclose" name="thuclose" id="close">
                                                                    </div>
                                                                    <?php $__errorArgs = ['thuclose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-2">
                                                                <div class="form-group">
                                                                    <div class="custom-control custom-checkbox input-group check_center">
                                                                        <input type="checkbox" class="custom-control-input salonCheck" name="thu" value="thu" id="thu_check">
                                                                        <label class="custom-control-label" for="thu_check"></label>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <label for="phone" class="form-control-label"><?php echo e(__('Friday')); ?></label>
                                                        <div class="row align-items-center">
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('friopen', '08:00')); ?>" class="form-control day-section-friopen" name="friopen" id="open">
                                                                    </div>
                                                                    <?php $__errorArgs = ['friopen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('friclose','20:00')); ?>" class="form-control day-section-friclose" name="friclose" id="close">
                                                                    </div>
                                                                    <?php $__errorArgs = ['friclose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-2">
                                                                <div class="form-group">
                                                                    <div class="custom-control custom-checkbox input-group check_center">
                                                                        <input type="checkbox" class="custom-control-input salonCheck" name="fri" value="fri" id="fri_check">
                                                                        <label class="custom-control-label" for="fri_check"></label>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <label for="phone" class="form-control-label"><?php echo e(__('Saturday')); ?></label>
                                                        <div class="row align-items-center">
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('satopen', '08:00')); ?>" class="form-control day-section-satopen" name="satopen" id="open">
                                                                    </div>
                                                                    <?php $__errorArgs = ['satopen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-5">
                                                                <div class="form-group">
                                                                    <div class="input-group">
                                                                        <input type="text" value="<?php echo e(old('satclose', '20:00')); ?>" class="form-control day-section-satclose" name="satclose" id="close">
                                                                    </div>
                                                                    <?php $__errorArgs = ['satclose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-2">
                                                                <div class="form-group">
                                                                    <div class="custom-control custom-checkbox input-group check_center">
                                                                        <input type="checkbox" class="custom-control-input salonCheck" name="sat" value="sat" id="sat_check">
                                                                        <label class="custom-control-label" for="sat_check"></label>
                                                                        </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="text-right">
                                                            <a href="#tabs-icons-text-2" data-toggle="tab" role="tab" aria-controls="tabs-icons-text-2" class="btn btn-primary btnNext">Next</a>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="tab-pane fade" id="tabs-icons-text-3" role="tabpanel" aria-labelledby="tabs-icons-text-3-tab">
                                                    <div class="p-20">
                                                        <div class="row">
                                                            

                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label class="form-control-label" for="image"><?php echo e(__('Image')); ?></label><br>
                                                                <input type="file"  value="<?php echo e(old('image')); ?>" id="image" name="image" accept="image/*" onchange="loadFile(event)" ><br>
                                                                <img id="output" class="uploadsalonimg mt-3"/>
                                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label class="form-control-label"><?php echo e(__('Logo')); ?> </label><br>
                                                                <input type="file" name="logo" id="logo" accept="image/*" onchange="loadFile1(event)"><br>
                                                                <img  id="black_logo_output" class="mt-2 logo_size_salon">
                                                                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="address" class="form-control-label"><?php echo e(__('Address')); ?></label>
                                                                <input class="form-control" id="address" name="address" placeholder="<?php echo e(__('Address of salon')); ?>" value="<?php echo e(old('address')); ?>">
                                                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-4 d-none">
                                                            <div class="form-group">
                                                                <label for="zipcode" class="form-control-label"><?php echo e(__('Zipcode')); ?></label>
                                                                <input type="number" value="<?php echo e(old('zipcode')); ?>"  class="form-control" name="zipcode" id="zipcode" placeholder="<?php echo e(__('Zipcode')); ?>" >
                                                                <?php $__errorArgs = ['zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>

                                                        
                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="country" class="form-control-label"><?php echo e(__('Country')); ?></label>
                                                                <select name="country" id="country" class="form-control">
                                                                    <option value="United Arab Emirates">United Arab Emirates</option>
                                                                </select>
                                                                
                                                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>  
                                                        </div>
                                
                                                        
                                                        <div class="col-md-4">
                                                            <div class="form-group">
                                                                <label for="city" class="form-control-label"><?php echo e(__('City')); ?></label>
                                                                
                                                                <select name="city" id="city" class="form-control">
                                                                    <option value="Dubai">Dubai</option>
                                                                    <option value="Abu Dhabi">Abu Dhabi</option>
                                                                    <option value="Sharjah">Sharjah</option>
                                                                    <option value="Al Ain">Al Ain</option>
                                                                    <option value="Ajman">Ajman</option>
                                                                    <option value="Ras Al Khaimah">Ras Al Khaimah</option>
                                                                    <option value="Fujairah">Fujairah</option>
                                                                    <option value="Umm al-Quwain">Umm al-Quwain</option>
                                                                    <option value="Dibba Al-Fujairah">Dibba Al-Fujairah</option>
                                                                    <option value="Khor Fakkan">Khor Fakkan</option>
                                                                    <option value="Kalba">Kalba</option>
                                                                    <option value="Jebel Ali">Jebel Ali</option>
                                                                    <option value="Madinat Zayed">Madinat Zayed</option>
                                                                    <option value="Ruwais">Ruwais</option>
                                                                    <option value="Liwa Oasis">Liwa Oasis</option>
                                                                    <option value="Dhaid">Dhaid</option>
                                                                    <option value="Ghayathi">Ghayathi</option>
                                                                    <option value="Ar-Rams">Ar-Rams</option>
                                                                    <option value="Dibba Al-Hisn">Dibba Al-Hisn</option>
                                                                    <option value="Hatta">Hatta</option>
                                                                    <option value="Al Madam">Al Madam</option>
                                                                    <option value="Al Jazirah Al Hamra">Al Jazirah Al Hamra</option>
                                                                </select>
                                                                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                
                                                        
                                                        <div class="col-md-4 d-none">
                                                            <div class="form-group">
                                                                <label for="state" class="form-control-label"><?php echo e(__('State')); ?></label>
                                                                <input type="text" value="<?php echo e(old('state')); ?>"  class="form-control" name="state" id="state" placeholder="<?php echo e(__('State')); ?>" >
                                                                <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                                    <div class="invalid-div"><?php echo e($message); ?></div>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                
                                
                                                        
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <div class="mapsize my-0 mx-auto mb-4" id="location_map"></div>
                                                            </div>
                                                        </div>
                                
                                                        
                                                        <div class="form-group d-none">
                                                            <label class="form-control-label"><?php echo e(__('Latitude')); ?></label>
                                                            <?php $lat = \App\AdminSetting::find(1)->lat; ?>
                                                            <input type="text" class="form-control" value="<?php echo e($lat); ?>" name="lat" id="lat" readonly>
                                                        </div>
                                                        
                                                        
                                                        <div class="form-group d-none">
                                                            <label class="form-control-label"><?php echo e(__('Longitude')); ?></label>
                                                            <?php $lang = \App\AdminSetting::find(1)->lang; ?>
                                                            <input type="text" class="form-control" value="<?php echo e($lang); ?>" name="long" id="long" readonly>
                                                        </div>
                                                        

                                                    </div>
                                                    <div class="border-top">
                                                        <div class="card-body text-center">
                                                            <input type="submit" class="btn btn-primary" value="<?php echo e(__('Submit')); ?>">
                                                        </div>
                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.21/b-1.6.2/b-flash-1.6.2/b-html5-1.6.2/b-print-1.6.2/datatables.min.js"> </script>

    <script src="<?php echo e(asset('includes/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('includes/js/argon.js')); ?>"></script>
    <script src="<?php echo e(asset('includes/js/jquery.timepicker.js')); ?>"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
    <?php $mapkey = \App\AdminSetting::find(1)->mapkey; ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($mapkey); ?>" async defer></script>
    <script src="<?php echo e(asset('includes/js/map.js')); ?>"></script> 
    
    <script src="<?php echo e(asset('includes/js/myjavascript.js')); ?>"></script>
    <script>
        $('.btnNext').click(function(){
        $('.nav-item > a.nav-link.active').parent().next('li').find('a').trigger('click');
        });

        $('.btnPrevious').click(function(){
        $('.nav-item > a.nav-link.active').parent().prev('li').find('a').trigger('click');
        });
        

        $('input[type=radio][name=have_website]').on('change',function() {
            console.log('test');
            if (this.value == 'yes') {
                $('#website_div').removeClass('d-none');
            }
            else if (this.value == 'no') {
                $('#website_div').addClass('d-none');
            }
        });
    </script>
</body>

</html><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/owner/salon/create.blade.php ENDPATH**/ ?>