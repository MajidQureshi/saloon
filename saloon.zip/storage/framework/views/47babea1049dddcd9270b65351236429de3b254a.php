<?php $setting = \App\AdminSetting::find(1); ?>


<!-- ================================
            START HEADER AREA
================================= -->
<header class="header-area">
   
    <div class="header-top-bar py-2 padding-right-30px padding-left-30px border-top border-top-color">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 d-flex align-items-center header-top-info font-size-14">
                    <p class="mr-3 pr-3 border-right border-right-color">
                        <span class="mr-1 text-white font-weight-semi-bold"><?php echo e(__('layout.Email')); ?>:</span>
                        <a href="mailto:<?php echo e($setting->email); ?>" class="font-weight-medium"> <?php echo e($setting->email); ?> </a>
                    </p>
                    <p>
                        <span class="mr-1 text-white font-weight-semi-bold"><?php echo e(__('layout.Phone')); ?>:</span>
                        <a href="tel:<?php echo e($setting->phone); ?>" class="font-weight-medium"> <?php echo e($setting->phone); ?> </a>
                    </p>
                </div>
                <div class="col-lg-6 col-md-6 d-flex align-items-center justify-content-end header-top-info">
                    
                    <?php if(App::getLocale() == 'ar'): ?>
                        <div class="mr-2">
                            <a href="<?php echo e(LaravelLocalization::getLocalizedURL('en', null, [], true)); ?>">
                                <img src="/website/assets/img/uk-flag.png" width="45">
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="mr-2">
                            <a href="<?php echo e(LaravelLocalization::getLocalizedURL('ar', null, [], true)); ?>">
                                <img src="/website/assets/img/uae-flag.png" width="45">
                            </a>
                        </div>
                    <?php endif; ?>
                    <?php if(Auth::check()): ?>
                        <div class="dashboard-topbar">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle after-none" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <div class="user-thumb user-thumb-sm position-relative">
                                            <img src="<?php echo e(Auth::user()->imagePath); ?><?php echo e(Auth::user()->image); ?>" alt="author-image">
                                            <div class="status-indicator bg-success"></div>
                                        </div>
                                        <span class="ml-2 small font-weight-medium d-none d-lg-inline"> <?php echo e(Auth::user()->name); ?> </span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right py-2" aria-labelledby="userDropdown">
                                        <a class="dropdown-item text-color font-size-15" href="<?php echo e(url('/profile')); ?>">
                                            <i class="la la-user mr-2 text-gray font-size-18"></i>
                                            <?php echo e(__('layout.Profile')); ?>

                                        </a>
                                        <a class="dropdown-item text-color font-size-15" href="<?php echo e(url('/appointments')); ?>">
                                            <i class="la la-shopping-bag mr-2 text-gray font-size-18"></i>
                                            <?php echo e(__('layout.Bookings')); ?>

                                        </a>
                                        <a class="dropdown-item text-color font-size-15" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                                            <i class="la la-power-off mr-2 text-gray font-size-18"></i>
                                            <?php echo e(__('layout.Logout')); ?>

                                        </a>
                                        <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <p class="login-and-signup-wrap">
                            <a href="#" data-toggle="modal" data-target="#loginModal">
                                <span class="mr-1 la la-sign-in"></span><?php echo e(__('layout.Log In')); ?>

                            </a>
                            <span class="or-text px-2">or</span>
                            <a href="#" data-toggle="modal" data-target="#signUpModal">
                                <span class="mr-1 la la-user-plus"></span><?php echo e(__('layout.Sign Up')); ?>

                            </a>
                        </p>
                    <?php endif; ?>
                   
                </div>
            </div><!-- end row -->
        </div><!-- end container-fluid -->
    </div><!-- end header-top-bar -->
    <div class="header-menu-wrapper padding-right-30px padding-left-30px">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="menu-full-width">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(asset('storage/images/app/'.$setting->white_logo)); ?>" alt="logo" width="50">
                            </a>
                            <div class="d-flex align-items-center">
                                
                                <div class="menu-toggle">
                                    <span class="menu__bar"></span>
                                    <span class="menu__bar"></span>
                                    <span class="menu__bar"></span>
                                </div><!-- end menu-toggle -->
                            </div>
                        </div><!-- end logo -->
                       
                        <div class="main-menu-content ml-auto">
                            <nav class="main-menu">
                                <ul>
                                    <li>
                                        <a href="<?php echo e(url('/')); ?>" class="<?php echo e(request()->is('/')  ? 'active' : ''); ?>"> <?php echo e(__('layout.Home')); ?> </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('/ts-all-salons')); ?>" class="<?php echo e(request()->is('/')  ? 'active' : ''); ?>"> Test Salon </a>
                                    </li>
                                    <li>
                                        <a href="#"  class="<?php echo e(request()->is('all-categories')  ? 'active' : ''); ?>"> <?php echo e(__('layout.Categories')); ?> <span class="la la-angle-down"></span></a>
                                        <?php $categories = \App\Category::where('status',1)->get(['cat_id','name']); ?>
                                        <ul class="dropdown-menu-item">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e(url('/all-salons?category='.$item->cat_id)); ?>"> <?php echo e($item->name); ?> </a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(url('/all-categories')); ?>"> <?php echo e(__('layout.All Categories')); ?> </a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('/all-salons')); ?>" class="<?php echo e(request()->is('all-salons*')  ? 'active' : ''); ?>"> <?php echo e(__('layout.Salons')); ?> </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                        
                    </div><!-- end menu-full-width -->
                </div><!-- end col-lg-12 -->
            </div><!-- end row -->
        </div><!-- end container-fluid -->
    </div><!-- end header-menu-wrapper -->
</header>
<!-- ================================
         END HEADER AREA
================================= --><?php /**PATH E:\xampp\htdocs\SmartCitaHome\resources\views/website/layouts/header.blade.php ENDPATH**/ ?>