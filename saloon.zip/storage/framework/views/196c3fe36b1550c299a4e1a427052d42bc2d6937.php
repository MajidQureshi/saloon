
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.top-header', [
        'title' => __('Salon') ,
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container-fluid mt--6 mb-5 only_search">
    <div class="row">
      <div class="col">
        <div class="card">
          <div class="card-header border-0">
            <span class="h3"><?php echo e(__('Salon table')); ?></span>
          </div>
          <div class="table-responsive">
            <table class="table align-items-center table-flush"  id="dataTableUser">
              <thead class="thead-light">
                <tr>
                    <th scope="col" class="sort"><?php echo e(__('#')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Image')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Name')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Owner name')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Salon For')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Created_at')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Updated_at')); ?></th>
                    <th scope="col" class="sort"><?php echo e(__('Status')); ?></th>
                    <th></th>
                </tr>
            </thead>
              <tbody class="list">
                    <?php $__currentLoopData = $salons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                            <th><?php echo e($loop->iteration); ?></th>
                            <td>
                                <img src="<?php echo e(asset('storage/images/salon logos/'.$salon->image)); ?>" class="tableimage rounded">
                            </td>
                            <td><?php echo e($salon->name); ?></td>
                            <td><?php echo e($salon->ownerName); ?></td>
                            <td><?php echo e($salon->gender); ?></td>
                            <td><?php echo e($salon->created_at); ?></td>
                            <td><?php echo e($salon->updated_at); ?></td>
                            <td>
                              <label class="custom-toggle">
                                  <input type="checkbox"  onchange="hideSalon(<?php echo e($salon->salon_id); ?>)" <?php echo e($salon->status == 0?'checked': ''); ?>>
                                  <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Hide"></span>
                              </label>
                            </td>
                            <td class="table-actions">
                              <?php
                                $base_url = url('/');
                              ?>
                                <a href="<?php echo e(url('admin/salons/'.$salon->salon_id)); ?>" class="table-action text-warning" data-toggle="tooltip" data-original-title="<?php echo e(__('View Salon')); ?>">
                                      <i class="fas fa-eye"></i>
                                </a>
                                <button class="btn-white btn shadow-none p-0 m-0 table-action text-danger bg-white" onclick="deleteData('admin/salons',<?php echo e($salon->salon_id); ?>,'<?php echo e($base_url); ?>')" data-toggle="tooltip" data-original-title="<?php echo e(__('Delete Salon')); ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                          </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\SmartCitaHome\resources\views/admin/pages/salon.blade.php ENDPATH**/ ?>