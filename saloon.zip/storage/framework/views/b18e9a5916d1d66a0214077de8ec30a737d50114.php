<div class="container-fluid sidebar_open <?php if($errors->any()): ?> show_sidebar_create <?php endif; ?>" id="add_service_sidebar">
    <div class="row">
        <div class="col">
            <div class="card py-3 border-0">
                <div class="border_bottom_pink pb-3 pt-2 mb-4">
                    <span class="h3"><?php echo e(__('Create Service')); ?></span>
                    <button type="button" class="add_service close">&times;</button>
                </div>
                <form class="form-horizontal"  id="create_service_form" method="post" enctype="multipart/form-data" action="<?php echo e(url('/owner/service')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="my-0">
                        <div class="form-group">
                            <label class="form-control-label" for="name"><?php echo e(__('Service Name')); ?></label>
                            <input type="text" value="<?php echo e(old('name')); ?>" name="name" id="name" class="form-control" placeholder="<?php echo e(__('Service Name')); ?>"  autofocus>
                            <div class="invalid-div "><span class="name"></span></div>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label" for="image"><?php echo e(__('Image')); ?></label><br>
                            <input type="file" value="<?php echo e(old('image')); ?>" name="image" id="image" accept="image/*" onchange="loadFile(event)" ><br>
                            <img id="output" class="mt-3 offer_size h-50 w-50">
                            <div class="invalid-div "><span class="image"></span></div>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label" for="image"><?php echo e(__('Service For')); ?></label><br>
                            <div class="custom-control custom-radio mb-2">
                                <input type="radio" id="customRadio1" name="gender" value="Male" class="custom-control-input">
                                <label class="custom-control-label" for="customRadio1"><?php echo e(__('Male')); ?></label>
                            </div>
                            <div class="custom-control custom-radio mb-2">
                                <input type="radio" id="customRadio2" name="gender" value="Female" class="custom-control-input">
                                <label class="custom-control-label" for="customRadio2"><?php echo e(__('Female')); ?></label>
                            </div>
                            <div class="custom-control custom-radio">
                                <input type="radio" id="customRadio3" name="gender" value="Both" class="custom-control-input" checked>
                                <label class="custom-control-label" for="customRadio3"><?php echo e(__('Both')); ?></label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-control-label" for="price"><?php echo e(__('Service Price')); ?></label>
                            <input type="text" value="<?php echo e(old('price')); ?>" name="price" id="price" class="form-control" placeholder="<?php echo e(__('Service Price')); ?>" >
                            <div class="invalid-div "><span class="price"></span></div>
                        </div>

                        <div class="form-group">
                            <label class="form-control-label" for="time"><?php echo e(__('Service Time (Minutes)')); ?></label>
                            <input type="text" value="<?php echo e(old('time')); ?>" name="time" id="time" class="form-control" placeholder="<?php echo e(__('Service Time')); ?>" >
                            <div class="invalid-div "><span class="time"></span></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-control-label" for="cat_id"><?php echo e(__('Select Category')); ?></label>
                            <select class="form-control" name="cat_id"  value="<?php echo e(old('cat_id')); ?>">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->cat_id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-div "><span class="cat_id"></span></div>
                        </div>
                        
                        <div class="text-center">
                            <button type="button" id="create_btn" onclick="all_create('create_service_form','services')" class="btn btn-primary mt-4 mb-5 rtl-float-none"><?php echo e(__('Create')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/owner/service/create.blade.php ENDPATH**/ ?>