<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta
            name="description"
            content="The Best Booking System For Salons & Spas. 
            Sign Up Free. Grow Your Salon And Save Time "
        />

        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />

        <link
            rel="preload"
            href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap"
            as="style"
            onload="this.onload=null;this.rel='stylesheet'"
        />
        <noscript>
            <link
                href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap"
                rel="stylesheet"
            />
        </noscript>

        <!-- Swiper css -->

        <!-- Swiper js -->

        <!-- My javascript file -->

        <script defer src="../js/index.js"></script>
        <link rel="stylesheet" href="../styles/styles.css" />
        <title>Meetendo</title>
    </head>
<body>
    <?php echo $__env->make('website.layouts.salonheader-1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('website_content'); ?>

    <!-- end per-loader -->
    

    

    <?php echo $__env->make('website.layouts.newfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- start back-to-top -->


    
    
    
    
    

    <!-- Template JS Files -->


    <script src="<?php echo e(asset('includes/website/js/index.js')); ?>"></script>
</body>

</html><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/website/layouts/salonmaster.blade.php ENDPATH**/ ?>