<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="base_url" content="<?php echo e(url('/')); ?>">

        <?php $color = \App\AdminSetting::find(1)->color; ?>
        <style>
            :root{
                --primary_color : <?php echo $color ?>;
                --primary_color_hover : <?php echo $color.'cc' ?>;
            }
        </style>

        <?php $app_name = \App\AdminSetting::find(1)->app_name; ?>
        <title><?php echo e($app_name); ?></title>

        <?php $favicon = \App\AdminSetting::find(1)->favicon; ?>
        <link href="<?php echo e(asset('storage/images/app/'.$favicon)); ?>" rel="icon" type="image/png">

        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

        <link href="<?php echo e(asset('includes/css/nucleo.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('includes/css/all.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('includes/css/sweetalert2.scss')); ?>">
        <link href="<?php echo e(asset('includes/css/jquery.timepicker.css')); ?>" rel="stylesheet">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.21/b-1.6.2/b-flash-1.6.2/b-html5-1.6.2/b-print-1.6.2/datatables.min.css" />
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.15/dist/summernote.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>

        <link href="<?php echo e(asset('includes/css/argon.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('includes/css/mystyle.css')); ?>" rel="stylesheet">
        <?php if(session('direction') == "rtl"): ?>
            <link href="<?php echo e(asset('includes/css/rtl.css')); ?>" rel="stylesheet">
        <?php endif; ?>

        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
        <link href="<?php echo e(asset('includes/css/bootstrap-wizard.css')); ?>" rel="stylesheet">
    </head>
    <body class="<?php echo e($class ?? ''); ?>">
        <?php if(Request::url() != url('/owner/calendar')): ?>
            <div class="preload" id="preload">
                <img src="<?php echo e(asset('storage/images/app/loader.gif')); ?>" class="loader" alt="">
            </div>
            <div class="for-loader">
        <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <div class="main-content">
                <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->yieldContent('content_setting'); ?>

            </div>

            <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>


            <script src="<?php echo e(asset('includes/js/Chart.min.js')); ?>"></script>
            <script src="<?php echo e(asset('includes/js/Chart.extension.js')); ?>"></script>
            <script src="<?php echo e(asset('includes/js/jquery.min.js')); ?>"></script>
            <script src="<?php echo e(asset('includes/js/bootstrap.bundle.min.js')); ?>"></script>
            <script src="<?php echo e(asset('includes/js/argon.js')); ?>"></script>
            <script src="<?php echo e(asset('includes/js/jquery.scrollbar.min.js')); ?>"></script>
            <script src="<?php echo e(asset('includes/js/jquery-scrollLock.min.js')); ?>"></script>
            <script src="<?php echo e(asset('includes/js/sweetalert.all.js')); ?>"></script>
            <script src="<?php echo e(asset('includes/js/jquery.timepicker.js')); ?>"></script>


            <script src="<?php echo e(asset('includes/js/map.js')); ?>"></script>
            <?php $mapkey = \App\AdminSetting::find(1)->mapkey; ?>
            <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($mapkey); ?>" async defer></script>

            <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
            <script src="//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/promise-polyfill@8/dist/polyfill.js"></script>



            <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
            <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>

            <script type="text/javascript" src="https://cdn.datatables.net/v/bs4/jszip-2.5.0/dt-1.10.21/b-1.6.2/b-flash-1.6.2/b-html5-1.6.2/b-print-1.6.2/datatables.min.js"> </script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
            <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
            <script src="<?php echo e(asset('includes/js/myjavascript.js')); ?>"></script>
            <script src="<?php echo e(asset('includes/js/bootstrap-wizard.js')); ?>"></script>
            <?php echo $__env->yieldPushContent('js'); ?>

        <?php if(Request::url() != url('/owner/calendar')): ?>
        </div>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH E:\xampp\htdocs\SmartCitaHome\resources\views/layouts/app.blade.php ENDPATH**/ ?>