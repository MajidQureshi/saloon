
<?php $__env->startSection('content'); ?>





<?php $bg_img = \App\AdminSetting::find(1)->bg_img; ?>
<div class="header pt-9" style="background-image: url(<?php echo e(asset('storage/images/app/'.$bg_img)); ?>); background-size: cover; background-position: center center;padding-bottom: 50px;">
    <span class="mask bg-gradient-dark opacity-7"></span>
    <div class="container-fluid">
        <div class="header-body">
            <div class="row">
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Clients')); ?></h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e(count($users)); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                        <i class="fa fa-user"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-muted text-sm">
                                <span class="text-nowrap"><?php echo e(__('Since app launch')); ?></span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Services')); ?></h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e(count($services)); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-green text-white rounded-circle shadow">
                                        <i class="ni ni-scissors"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-muted text-sm">
                                <span class="text-nowrap"><?php echo e(__('Since app launch')); ?></span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Income')); ?></h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e($symbol); ?><?php echo e(ceil($salon_income)); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-warning text-white rounded-circle shadow">
                                        <i class="ni ni-money-coins"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-muted text-sm">
                                <span class="text-nowrap"><?php echo e(__('Since app launch')); ?></span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0"><?php echo e(__('Employees')); ?></h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e(count($employees)); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                                        <i class="fas fa-users"></i>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-3 mb-0 text-muted text-sm">
                                <span class="text-nowrap"><?php echo e(__('Since app launch')); ?></span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                    

<div class="container-fluid mt--4">
    <div class="row">
        <div class="col-xl-12 mb-5 mb-xl-0">
            <div class="card shadow">
                <div class="card-header bg-transparent">
                    <div class="row align-items-center">
                        <div class="col">
                            <h6 class="text-uppercase text-muted ls-1 mb-1"><?php echo e(__('PERFORMANCE')); ?></h6>
                            <h2 class="text-default mb-0"><?php echo e(__('Orders')); ?></h2>
                        </div>
                        <div class="col">
                            <ul class="nav nav-pills justify-content-end">
                                <li class="nav-item mr-2 mr-md-0" data-toggle="chart" data-target="#orders_chart">
                                    <a href="#" class="nav-link py-2 px-3 active" data-toggle="tab" id="ownerWeekOrder">
                                        <span class="d-none d-md-block"><?php echo e(__('Week')); ?></span>
                                        <span class="d-md-none"><?php echo e(__('W')); ?></span>
                                    </a>
                                </li>
                                                                                                                        
                                <li class="nav-item mr-2 mr-md-0" data-toggle="chart" data-target="#orders_chart">
                                    <a href="#" class="nav-link py-2 px-3" data-toggle="tab" id="ownerMonthOrder">
                                        <span class="d-none d-md-block"><?php echo e(__('Month')); ?></span>
                                        <span class="d-md-none"><?php echo e(__('M')); ?></span>
                                    </a>
                                </li>
                                
                                <li class="nav-item mr-2 mr-md-0" data-toggle="chart" data-target="#orders_chart">
                                    <a href="#" class="nav-link py-2 px-3" data-toggle="tab" id="ownerYearOrder">
                                        <span class="d-none d-md-block"><?php echo e(__('Year')); ?></span>
                                        <span class="d-md-none"><?php echo e(__('Y')); ?></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="chart">
                        <canvas id="orders_chart" class="chart-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-xl-12 mb-5 mb-xl-0">
            <div class="card shadow">
                <div class="card-header bg-transparent">
                    <div class="row align-items-center">
                        <div class="col">
                            <h6 class="text-uppercase text-muted ls-1 mb-1"><?php echo e(__('INCOME')); ?></h6>
                            <h2 class="text-default mb-0"><?php echo e(__('Revenue')); ?></h2>
                        </div>
                        <div class="col">
                            <ul class="nav nav-pills justify-content-end">
                                <li class="nav-item mr-2 mr-md-0" data-toggle="chart" data-target="#revenue_owner_chart">
                                    <a href="#" class="nav-link py-2 px-3 active" data-toggle="tab" id="ownerWeekRevenue">
                                        <span class="d-none d-md-block"><?php echo e(__('Week')); ?></span>
                                        <span class="d-md-none"><?php echo e(__('W')); ?></span>
                                    </a>
                                </li>
                                                                                                                        
                                <li class="nav-item mr-2 mr-md-0" data-toggle="chart" data-target="#revenue_owner_chart">
                                    <a href="#" class="nav-link py-2 px-3" data-toggle="tab" id="ownerMonthRevenue">
                                        <span class="d-none d-md-block"><?php echo e(__('Month')); ?></span>
                                        <span class="d-md-none"><?php echo e(__('M')); ?></span>
                                    </a>
                                </li>
                                
                                <li class="nav-item mr-2 mr-md-0" data-toggle="chart" data-target="#revenue_owner_chart">
                                    <a href="#" class="nav-link py-2 px-3" data-toggle="tab" id="ownerYearRevenue">
                                        <span class="d-none d-md-block"><?php echo e(__('Year')); ?></span>
                                        <span class="d-md-none"><?php echo e(__('Y')); ?></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="chart">
                        <canvas id="revenue_owner_chart" class="chart-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="container-fluid mt-4 mb-4">
    
    <div class="row">
        <div class="col-xl-4 mb-5 mb-xl-0">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="mb-0"><?php echo e(__('Top Services')); ?></h3>
                        </div>
                        <div class="col text-right">
                            <a href="<?php echo e(url('/owner/services')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('See all')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo e(__('#')); ?></th>
                                <th scope="col"><?php echo e(__('Image')); ?></th>
                                <th scope="col"><?php echo e(__('Name')); ?></th>
                                <th scope="col"><?php echo e(__('Category')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($top_services) != 0): ?>
                                <?php $__currentLoopData = $top_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($loop->iteration); ?></th>
                                        <td>
                                            <img src="<?php echo e(asset('storage/images/services/'.$service->image)); ?>" class="icon rounded-circle">
                                        </td>
                                        <td><?php echo e($service->name); ?></td>
                                        <td><?php echo e($service->category->name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <th colspan="10" class="text-center"><?php echo e(__('Service not booked by any client')); ?></th>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="col-xl-8">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="mb-0"><?php echo e(__('Upcoming Approved Appointments')); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col"><?php echo e(__('Booking Id')); ?></th>
                                <th scope="col"><?php echo e(__('User Name')); ?></th>
                                <th scope="col"><?php echo e(__('Service')); ?></th>
                                <?php if($give_service == "Both"): ?>
                                    <th scope="col"><?php echo e(__('Booking At')); ?></th>
                                <?php endif; ?>
                                <th scope="col"><?php echo e(__('Date')); ?></th>
                                <th scope="col"><?php echo e(__('Time')); ?></th>
                                <th scope="col"><?php echo e(__('Payment')); ?></th>
                                <th scope="col"><?php echo e(__('Payment Status')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($upcommings) != 0): ?>
                                <?php $__currentLoopData = $upcommings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upcomming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($upcomming->booking_id); ?></th>
                                        <td><?php echo e($upcomming->user->name); ?></td>
                                        <td>
                                            <div class="avatar-group">
                                                <?php $__currentLoopData = $upcomming->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="#" class="avatar avatar-sm rounded-circle" data-toggle="tooltip" data-original-title="<?php echo e($service->name); ?>">
                                                        <img alt="service" class="service_icon" src="<?php echo e(asset('storage/images/services/'.$service->image)); ?>">
                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </td>
                                        <?php if($give_service == "Both"): ?>
                                            <td> <?php echo e($upcomming->booking_at); ?> </td>
                                        <?php endif; ?>
                                        <td><?php echo e($upcomming->date); ?></td>
                                        <td><?php echo e($upcomming->start_time); ?></td>
                                        <td><?php echo e($symbol); ?><?php echo e($upcomming->payment); ?></td>
                                        <td class="text-center">
                                            <?php if($upcomming->payment_status == 1): ?>
                                                <span class="badge badge-pill badge-success"><?php echo e(__('Paid')); ?></span>
                                            <?php elseif($upcomming->payment_status == 0): ?>
                                                <span class="badge badge-pill badge-warning"><?php echo e(__('Unpaid')); ?></span>
                                            <?php endif; ?> 
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <th colspan="10" class="text-center"><?php echo e(__('No Upcomming Appointments')); ?></th>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/owner/pages/dashboard.blade.php ENDPATH**/ ?>