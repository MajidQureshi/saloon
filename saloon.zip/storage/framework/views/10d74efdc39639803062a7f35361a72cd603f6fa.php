
<?php $__env->startSection('website_content'); ?>
<?php echo $__env->make('website.layouts.breadcrumb', [
    'title' => __('Booking'),
    'headerData' => __('Salon'),
    'url' => 'all-salons',
    'headerData2' => $salon->name,
    'url2' => 'salon/'.$salon->salon_id .'/'. Str::slug($salon->name)
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- ================================
    START BOOKING AREA
================================= -->

<section class="booking-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="form-wizard">
                    <div class="form-wizard-header">
                        <ul class="list-unstyled form-wizard-steps clearfix">
                            <li class="active"><span>1</span></li>
                            <li><span>2</span></li>
                            <li><span>3</span></li>
                            <li><span>4</span></li>
                            <li><span>5</span></li>
                        </ul>
                    </div>
                    
                    <form action="<?php echo e(url('/booking')); ?>" method="POST" class="form-box" id="thisform">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($salon->salon_id); ?>" class="salon_id" name="salon_id">
                        <input type="hidden" value="<?php echo e(Str::slug($salon->name)); ?>" class="salon_name" name="salon_name">
                        <fieldset class="wizard-fieldset show">
                            <div class="block-card mb-4">
                                <div class="block-card-header">
                                    <h3 class="widget-title"> <?php echo e(__('layout.Select Services')); ?> </h3>
                                    <div class="stroke-shape"></div>
                                </div>
                                <div class="cat-tabs row mt-4">
                                    <div class="section-tab section-tab-layout-2 mb-4 col-lg-4">
                                        <ul class="nav nav-tabs cat-nav" id="myTab" role="tablist">
                                            <?php $__currentLoopData = $salon->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item">
                                                    <a class="nav-link <?php echo e($loop->iteration == 1 ? 'active':''); ?>"  data-toggle="tab" href="#<?php echo e($cat->name); ?>" role="tab" aria-selected="true">
                                                        <?php echo e($cat->name); ?>

                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <div class="tab-content col-lg-8" id="myTabContent">
                                        <?php $__currentLoopData = $salon->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane <?php echo e($loop->iteration == 1 ? 'active show':''); ?>" id="<?php echo e($cat->name); ?>" role="tabpanel" >
                                                <?php $__currentLoopData = $cat->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="mini-list-card checkbox display-block">
                                                        <input type="hidden" name="name-<?php echo e($service->service_id); ?>" value="<?php echo e($service->name); ?>">
                                                        <input type="hidden" name="price-<?php echo e($service->service_id); ?>" value="<?php echo e($service->price); ?>">
                                                        <label class="checkbox-wrapper">
                                                            <input type="checkbox" name="service_id[]" class="checkbox-input services wizard-required" value="<?php echo e($service->service_id); ?>"/>
                                                            <div class="checkbox-tile">
                                                                <div class="mini-list-img">
                                                                    <div class="d-block">
                                                                        <img src="<?php echo e($service->imagePath .'/'. $service->image); ?>" alt="<?php echo e($service->name); ?>">
                                                                    </div>
                                                                </div>
                                                                <div class="mini-list-body w-100">
                                                                    <h4 class="mini-list-title display-inline-block"> <?php echo e($service->name); ?> </h4>
                                                                    <span class="category-link after-none pl-0 font-size-15 font-weight-semi-bold float-right">
                                                                        <?php echo e($service->price); ?><?php echo e($setting->currency_symbol); ?>

                                                                    </span><br>
                                                                    <span class="category-link after-none pl-0 font-size-14 font-weight-medium">
                                                                        <i class="la la-clock mr-1 listing-icon text-color-2"></i> <?php echo e($service->time); ?> <?php echo e(__('layout.Min')); ?>

                                                                    </span>
                                                                    <?php if($salon->gender == "Both"): ?>
                                                                        <p class="pb-2 font-size-14 font-weight-medium">
                                                                            <?php if($service->gender == "Male"): ?>
                                                                                <i class="la la-mars mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Male')); ?>

                                                                            <?php elseif($service->gender == "Female"): ?>
                                                                                <i class="la la-venus mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Female')); ?>

                                                                            <?php else: ?>
                                                                                <i class="la la-venus-mars mr-1 listing-icon text-color-2"></i> <?php echo e(__('layout.Unisex')); ?>

                                                                            <?php endif; ?>
                                                                        </p>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="form-group clearfix">
                                    <a href="javascript:;" class="form-wizard-next-btn theme-btn gradient-btn border-0 shadow-none float-right"><?php echo e(__('layout.Next')); ?></a>
                                </div>
                            </div>
                        </fieldset>	

                        <fieldset class="wizard-fieldset">
                            <div class="block-card mb-4">
                                <div class="block-card-header">
                                    <?php if($salon->give_service != 'Salon'): ?>
                                        <h3 class="widget-title"> <?php echo e(__('layout.Select Time & Place')); ?> </h3>
                                    <?php else: ?>
                                        <h3 class="widget-title"> <?php echo e(__('layout.Select Time')); ?> </h3>
                                    <?php endif; ?>
                                    <div class="stroke-shape"></div>
                                </div>
                                <div class="form-group">
                                    <span class="la la-calendar-o form-icon"></span>
                                    <input class="date-dropper-input form-control wizard-required" type="text" name="date" placeholder="Select Date"/>
                                </div>

                                <div class="user-chosen-select-container">
                                    <select class="user-chosen-select wizard-required" name="timeslot" id="timeslot">
                                        <option value="0" disabled selected><?php echo e(__('layout.Time Slots')); ?></option>
                                    </select>
                                </div>
                                
                                <?php if($salon->give_service == 'Both'): ?>
                                    <div class="form-group">
                                        <div class="user-chosen-select-container">
                                            <select class="user-chosen-select wizard-required" name="service_at" id="service_at">
                                                <option value="Salon" selected> <?php echo e(__('layout.At Salon')); ?> </option>
                                                <option value="Home"> <?php echo e(__('layout.At Home')); ?>  </option>
                                            </select>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if($salon->give_service == "Both" || $salon->give_service == 'Home' ): ?>
                                    <div class="form-group <?php echo e($salon->give_service == 'Home' ? '':'display-none'); ?>" id="address_div">
                                        <div class="user-chosen-select-container">
                                            <select class="user-chosen-select <?php echo e($salon->give_service == 'Home' ? 'wizard-required':''); ?>" name="address" id="choose_address">
                                                <?php if(count($addresses) > 0): ?>
                                                    <option value="0" disabled selected> <?php echo e(__('layout.Choose Address')); ?> </option>
                                                    <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->address_id); ?>"> <?php echo e($item->street); ?>, <?php echo e($item->city); ?>, <?php echo e($item->state); ?>, <?php echo e($item->country); ?> </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <option value="0" disabled selected> <?php echo e(__('layout.Choose Address')); ?> </option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="form-group clearfix">
                                    <a href="javascript:;" class="form-wizard-previous-btn theme-btn gradient-btn border-0 shadow-none float-left"><?php echo e(__('layout.Previous')); ?></a>
                                    <a href="javascript:;" class="form-wizard-next-btn theme-btn gradient-btn border-0 shadow-none float-right next-staff"><?php echo e(__('layout.Next')); ?></a>
                                </div>
                            </div>
                        </fieldset>

                        <fieldset class="wizard-fieldset">
                            <div class="block-card mb-4">
                                <div class="block-card-header mb-2">
                                    <h3 class="widget-title"> <?php echo e(__('layout.Select Staff')); ?> </h3>
                                    <div class="stroke-shape"></div>
                                </div>
                                <div class="emp-list mt-4">
                                    <div class="emp_list">
                                        <?php echo $__env->make('website.pages.empList', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                                <div class="form-group clearfix">
                                    <a href="javascript:;" class="form-wizard-previous-btn theme-btn gradient-btn border-0 shadow-none float-left"><?php echo e(__('layout.Previous')); ?></a>
                                    <a href="javascript:;" class="form-wizard-next-btn theme-btn gradient-btn border-0 shadow-none float-right"><?php echo e(__('layout.Next')); ?></a>
                                </div>
                            </div>
                        </fieldset>	

                        <fieldset class="wizard-fieldset">
                            <div class="block-card mb-4">
                                <div class="block-card-header">
                                    <h3 class="widget-title"> <?php echo e(__('layout.Use Coupon')); ?> </h3>
                                    <div class="stroke-shape"></div>
                                </div>
                                <div class="coupon-widget">
                                    <div class="input-box">
                                        <div class="form-group mb-0">
                                            <input class="form-control pl-3" type="text" name="coupon_code" placeholder="Enter code" readonly>
                                            <button class="theme-btn gradient-btn border-0 shadow-none apply_coupon" type="button"><?php echo e(__('layout.Apply')); ?> <i class="la la-arrow-right ml-1"></i></button>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" value="" name="coupon_id">
                                
                                <div class="form-group clearfix">
                                    <a href="javascript:;" class="form-wizard-previous-btn theme-btn gradient-btn border-0 shadow-none float-left"><?php echo e(__('layout.Previous')); ?></a>
                                    <a href="javascript:;" class="form-wizard-next-btn theme-btn gradient-btn border-0 shadow-none float-right next-payment"><?php echo e(__('layout.Next')); ?></a>
                                </div>
                            </div>
                        </fieldset>

                        <fieldset class="wizard-fieldset">
                            <div class="block-card mb-4">
                                <div class="block-card-header">
                                    <h3 class="widget-title"> <?php echo e(__('layout.Select Payment Method')); ?> </h3>
                                    <div class="stroke-shape"></div>
                                </div>
                                <div class="block-card-body">
                                    <div class="payment-option-wrap">
                                        <div class="payment-tab is-active">
                                            <div class="payment-tab-toggle">
                                                <input checked id="cash" name="payment_type" type="radio" value="LOCAL">
                                                <label for="cash"> <?php echo e(__('layout.Cash')); ?> </label>
                                            </div>
                                            <div class="payment-tab-content">
                                                <p> <?php echo e(__('layout.Make your payment in cash at place of service held')); ?>.</p>
                                            </div>
                                        </div>
                                        <?php
                                            $stripe = \App\PaymentSetting::first()->stripe;
                                        ?>
                                        <?php if($stripe): ?>
                                            <div class="payment-tab">
                                                <div class="payment-tab-toggle">
                                                    <input id="stripe" name="payment_type" type="radio" value="STRIPE">
                                                    <label for="stripe"> <?php echo e(__('layout.Stripe')); ?> </label>
                                                </div>
                                                <div class="payment-tab-content">
                                                    <p><?php echo e(__('layout.In order to complete your transaction, we will transfer you over to Stripes secure servers')); ?>.</p>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group clearfix">
                                    <?php if($stripe): ?>
                                        <input type="hidden" value="<?php echo e($setting->stripe_public_key); ?>" name="stripePublicKey" id="stripePublicKey">
                                    <?php endif; ?>
                                    <input type="hidden" value="0" name="payment">
                                    <input type="hidden" value="0" name="discount">
                                    <a href="javascript:;" class="form-wizard-previous-btn theme-btn gradient-btn border-0 shadow-none float-left"><?php echo e(__('layout.Previous')); ?></a>
                                    <div class="stripe-form display-none"></div>
                                    <button type="button" id="cod_submit" onclick="booking()" class="form-wizard-submit theme-btn gradient-btn border-0 shadow-none float-right"><?php echo e(__('layout.Submit')); ?></button>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div><!-- end col-lg-8 -->
            <div class="col-lg-4">
                <div class="block-card">
                    <div class="block-card-header">
                        <h3 class="widget-title"><?php echo e(__('layout.Booking Summary')); ?></h3>
                        <div class="stroke-shape"></div>
                    </div><!-- block-card-header -->
                    <div class="block-card-body">
                        <div class="booking-summary">
                            <ul class="list-items list--items">
                                <li><span class="text-color"><?php echo e(__('layout.Date')); ?>:</span> <span class="selected_date">-</span> </li>
                                <li><span class="text-color"><?php echo e(__('layout.Time')); ?>:</span> <span class="selected_time">-</span> </li>
                                <?php if($salon->give_service == "Salon" || $salon->give_service == "Both" ): ?>
                                    <li><span class="text-color"><?php echo e(__('layout.Place')); ?>:</span> <span class="service_at"><?php echo e(__('layout.Salon')); ?> </span> </li>
                                <?php elseif($salon->give_service == "Home"): ?>
                                    <li><span class="text-color"><?php echo e(__('layout.Place')); ?>:</span> <span class="service_at"> <?php echo e(__('layout.Home')); ?> </span> </li>
                                <?php endif; ?>
                                <li class="display-none" id="address_show"><span class="text-color"><?php echo e(__('layout.Address')); ?>:</span> <span class="address">-</span> </li>
                                <li><span class="text-color"><?php echo e(__('layout.Staff')); ?>:</span> <span class="selected_staff">-</span> </li>

                            </ul>
                            <div class="section-block-2 my-3"></div>
                            <div class="selected_services"></div>
                            <?php if($salon->give_service != "Salon"): ?>
                                <div class="display-none" id="home_charges">
                                    <div class="widget-title d-flex align-items-center justify-content-between font-size-16 pb-0"><?php echo e(__('layout.Extra Charges')); ?>: <span class="font-weight-medium"><span class="home_charges"><?php echo e($salon->home_charges); ?></span><?php echo e($setting->currency_symbol); ?></span></div>
                                </div>
                            <?php endif; ?>
                            <div class="display-none" id="display_discount">
                                <div class="widget-title d-flex align-items-center justify-content-between font-size-16 pb-0"><?php echo e(__('layout.Discount')); ?>: <span class="font-weight-medium"> <span class="total_discount">0</span><?php echo e($setting->currency_symbol); ?></span></div>
                            </div>
                            <div class="widget-title d-flex align-items-center justify-content-between font-size-16 pb-0"><?php echo e(__('layout.Total Cost')); ?>: <span class="text-color-2 font-weight-semi-bold"> <span class="total_cost">0</span><?php echo e($setting->currency_symbol); ?></span></div>
                            <div class="section-block-2 my-3"></div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ================================
    END BOOKING AREA
================================= -->

<script src="<?php echo e(asset('includes/website/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('includes/website/js/datedropper.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\SmartCitaHome\resources\views/website/pages/bookingPage.blade.php ENDPATH**/ ?>