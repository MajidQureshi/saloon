
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.top-header', [
        'title' => __('Service'),
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--6 mb-5">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-0">
                    <span class="h3"><?php echo e(__('Services table')); ?></span>
                    <button class="btn btn-primary addbtn float-right p-2 add_service" id="add_service"><i class="fas fa-plus mr-1"></i><?php echo e(__('Add New')); ?></button>

                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col" class="sort"><?php echo e(__('#')); ?></th>
                            <th scope="col" class="sort"><?php echo e(__('Image')); ?></th>
                            <th scope="col" class="sort"><?php echo e(__('Name')); ?></th>
                            <th scope="col" class="sort"><?php echo e(__('Category')); ?></th>
                            <th scope="col" class="sort"><?php echo e(__('Time')); ?></th>
                            <th scope="col" class="sort"><?php echo e(__('Price')); ?></th>
                            <th scope="col" class="sort"><?php echo e(__('Status')); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody class="list">
                        <?php if(count($services) != 0): ?>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($services->firstItem() + $key); ?></th>
                                    <td>
                                        <img src="<?php echo e(asset('storage/images/services/'.$service->image)); ?>" class="tableimage rounded">
                                    </td>
                                    <td><?php echo e($service->name); ?></td>
                                    <td><?php echo e($service->category->name); ?></td>
                                    <td><?php echo e($service->time); ?> <?php echo e(__('Min')); ?></td>
                                    <td><?php echo e($service->price); ?><?php echo e($symbol); ?></td>
                                    <td>
                                        <label class="custom-toggle">
                                            <input type="checkbox"  onchange="hideService(<?php echo e($service->service_id); ?>)" <?php echo e($service->status == 0?'checked': ''); ?>>
                                            <span class="custom-toggle-slider rounded-circle" data-label-off="No" data-label-on="Hide"></span>
                                        </label>
                                    </td>
                                    <td class="table-actions">
                                        <?php
                                            $base_url = url('/');
                                        ?>
                                        <button class="btn-white btn shadow-none p-0 m-0 table-action text-warning bg-white" onclick="show_service(<?php echo e($service->service_id); ?>,'<?php echo e($base_url); ?>')" data-toggle="tooltip" data-original-title="<?php echo e(__('View Service')); ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn-white btn shadow-none p-0 m-0 table-action text-info bg-white" onclick="edit_service(<?php echo e($service->service_id); ?>,'<?php echo e($base_url); ?>')" data-toggle="tooltip" data-original-title="<?php echo e(__('Edit Service')); ?>">
                                            <i class="fas fa-user-edit"></i>
                                        </button>
                                        <button class="btn-white btn shadow-none p-0 m-0 table-action text-danger bg-white" onclick="deleteData('owner/services',<?php echo e($service->service_id); ?>,'<?php echo e($base_url); ?>')" data-toggle="tooltip" data-original-title="<?php echo e(__('Delete Service')); ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php else: ?>
                            <tr>
                                <th colspan="11" class="text-center"><?php echo e(__('No Services')); ?></th>
                            </tr>
                        <?php endif; ?>
                        
                    </tbody>
                </table>
                <div class="float-right mr-4 mb-1">
                    <?php echo e($services->links()); ?>

                </div>
            </div>
        </div>
      </div>
    </div>
</div>


<?php echo $__env->make('owner.service.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('owner.service.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('owner.service.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/owner/pages/service.blade.php ENDPATH**/ ?>