{!! $calendar->calendar() !!}
{!! $calendar->script() !!}