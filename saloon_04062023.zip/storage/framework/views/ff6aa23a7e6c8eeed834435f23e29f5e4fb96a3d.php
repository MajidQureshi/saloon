<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <?php $black_logo = \App\AdminSetting::find(1)->black_logo; ?>
        <?php if(Auth()->user()->role == 1): ?>
        <a class="navbar-brand p-0" href="<?php echo e(url('admin/dashboard')); ?>">
            <img src="<?php echo e(asset('storage/images/app/'.$black_logo)); ?>" class="navbar-brand-img sidebar-logo" alt="...">
        </a>
        <?php elseif(Auth()->user()->role == 2): ?>
        <a class="navbar-brand p-0" href="<?php echo e(url('owner/dashboard')); ?>">
            <img src="<?php echo e(asset('storage/images/app/'.$black_logo)); ?>" class="navbar-brand-img sidebar-logo" alt="...">
        </a>
        <?php endif; ?>

        <ul class="nav align-items-center d-md-none">
            <li class="nav-item dropdown">
                
    <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
        <div class=" dropdown-header noti-title">
            <h6 class="text-overflow m-0"><?php echo e(__('Welcome!')); ?></h6>
        </div>
        <?php if(Auth()->user()->role == 2): ?>
        <a href="<?php echo e(url('/owner/profile/'.Auth::user()->id)); ?>" class="dropdown-item">
            <i class="ni ni-single-02"></i>
            <span><?php echo e(__('My profile')); ?></span>
        </a>
        <?php elseif(Auth()->user()->role == 1): ?>
        <a href="<?php echo e(url('/admin/profile/'.Auth::user()->id)); ?>" class="dropdown-item">
            <i class="ni ni-single-02"></i>
            <span><?php echo e(__('My profile')); ?></span>
        </a>
        <?php endif; ?>
        <div class="dropdown-divider"></div>
        <?php if(Auth()->user()->role == 2): ?>
        <a href="<?php echo e(url('/owner/logout/')); ?>" class="dropdown-item">
            <i class="ni ni-single-02"></i>
            <span><?php echo e(__('Logout')); ?></span>
        </a>
        <?php elseif(Auth()->user()->role == 1): ?>
        <a href="<?php echo e(url('/admin/logout/')); ?>" class="dropdown-item">
            <i class="ni ni-single-02"></i>
            <span><?php echo e(__('Logout')); ?></span>
        </a>
        <?php endif; ?>
    </div>
    </li>
    </ul>
    <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <div class="navbar-collapse-header d-md-none">
            <div class="row">
                <div class="col-6 collapse-brand">
                    <?php if(Auth()->user()->role == 1): ?>
                    <a class="navbar-brand pt-0" href="<?php echo e(url('admin/dashboard')); ?>">
                        <img src="<?php echo e(asset('storage/images/app/'.$black_logo)); ?>" class="navbar-brand-img" alt="...">
                    </a>
                    <?php elseif(Auth()->user()->role == 2): ?>
                    <a class="navbar-brand pt-0" href="<?php echo e(url('owner/dashboard')); ?>">
                        <img src="<?php echo e(asset('storage/images/app/'.$black_logo)); ?>" class="navbar-brand-img" alt="...">
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <?php if(Auth()->user()->role == 1): ?>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/dashboard')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/dashboard')); ?>">
                    <i class="ni ni-tv-2 text-teal"></i>
                    <span class="nav-link-text"><?php echo e(__('Dashboard')); ?></span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/salonowners*')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/salonowners')); ?>">
                    <i class="fa fa-user-circle text-red"></i>
                    <span class="nav-link-text"><?php echo e(__('Salon Owner')); ?></span>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link <?php echo e(request()->is('admin/salons*')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/salons')); ?>">
                    <i class="ni ni-scissors text-blue"></i>
                    <span class="nav-link-text"><?php echo e(__('Salon')); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/users*')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/users')); ?>">
                    <i class="fa fa-user text-cyan"></i>
                    <span class="nav-link-text"><?php echo e(__('Users')); ?></span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/categories*')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/categories')); ?>">
                    <i class="fa fa-list text-orange"></i>
                    <span class="nav-link-text"><?php echo e(__('Category')); ?></span>
                </a>
            </li>

            

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/coupon*')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/coupon')); ?>">
                    <i class="fas fa-tag text-orange"></i>
                    <span class="nav-link-text"><?php echo e(__('Coupon')); ?></span>
                </a>
            </li>

            
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/subscriptions*')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/subscriptions')); ?>">
                    <i class="fas fa-asterisk text-blue"></i>
                    <span class="nav-link-text"><?php echo e(__('Subscription')); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/sub-features*')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/sub-features')); ?>">
                    <i class="fas fa-asterisk text-blue"></i>
                    <span class="nav-link-text"><?php echo e(__('Subscription Features')); ?></span>
                </a>
            </li>


            

            

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/review*')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/review')); ?>">
                    <i class="fas fa-star text-yellow"></i>
                    <span class="nav-link-text"><?php echo e(__('Reported Review')); ?></span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/report*')  ? 'active_text' : ''); ?>" href="#navbar-examples1" data-toggle="collapse" aria-expanded=" <?php echo e(request()->is('admin/report*')  ? 'true' : ''); ?>" role="button" aria-controls="navbar-examples">
                    <i class="fa fa-file text-blue"></i>
                    <span class="nav-link-text"><?php echo e(__('Reports')); ?></span>
                </a>

                <div class="collapse  <?php echo e(request()->is('admin/report*')  ? 'show' : ''); ?>" id="navbar-examples1">
                    <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('admin/report/user*')  ? 'active_text' : ''); ?>" href="<?php echo e(url('admin/report/user')); ?>"><?php echo e(__('User Report')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('admin/report/revenue*')  ? 'active_text' : ''); ?>" href="<?php echo e(url('admin/report/revenue')); ?>"><?php echo e(__('Revenue Report')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('admin/report/salon/revenue*')  ? 'active_text' : ''); ?>" href="<?php echo e(url('admin/report/salon/revenue')); ?>"><?php echo e(__('Salon Revenue Report')); ?></a>
                        </li>
                    </ul>
                </div>
            </li>

            
            

            

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('admin/settings*')  ? 'active' : ''); ?>" href="<?php echo e(url('admin/settings')); ?>">
                    <i class="fa fa-cog text-green"></i>
                    <span class="nav-link-text"><?php echo e(__('Settings')); ?></span>
                </a>
            </li>

        </ul>
        
        <?php elseif(Auth()->user()->role == 2): ?>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('owner/dashboard')  ? 'active' : ''); ?>" href="<?php echo e(url('owner/dashboard')); ?>">
                    <i class="ni ni-tv-2 text-teal"></i>
                    <span class="nav-link-text"><?php echo e(__('Dashboard')); ?></span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('owner/calendar*')  ? 'active' : ''); ?>" href="<?php echo e(url('owner/calendar')); ?>">
                    <i class="ni ni-calendar-grid-58 text-pink"></i>
                    <span class="nav-link-text"><?php echo e(__('Calendar')); ?></span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('owner/booking*')  ? 'active' : ''); ?>" href="<?php echo e(url('owner/booking')); ?>">
                    <i class="ni ni-collection text-blue"></i>
                    <span class="nav-link-text"><?php echo e(__('Booking')); ?></span>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link <?php echo e(request()->is('owner/users*')  ? 'active' : ''); ?>" href="<?php echo e(url('owner/users')); ?>">
                    <i class="fa fa-user text-cyan"></i>
                    <span class="nav-link-text "><?php echo e(__('Client')); ?></span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('owner/employee*')  ? 'active' : ''); ?>" href="<?php echo e(url('owner/employee')); ?>">
                    <i class="fa fa-users text-orange"></i>
                    <span class="nav-link-text"><?php echo e(__('Employee')); ?></span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('owner/services*')  ? 'active' : ''); ?>" href="<?php echo e(url('owner/services')); ?>">
                    <i class="fa fa-magic text-teal"></i>
                    <span class="nav-link-text"><?php echo e(__('Services')); ?></span>
                </a>
            </li>





            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('owner/gallery*')  ? 'active' : ''); ?>" href="<?php echo e(url('owner/gallery')); ?>">
                    <i class="fa fa-image  text-purple"></i>
                    <span class="nav-link-text"><?php echo e(__('Gallery')); ?></span>
                </a>
            </li>



            

            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('owner/settings*')  ? 'active' : ''); ?>" href="<?php echo e(url('owner/settings')); ?>">
                    <i class="fa fa-cog text-green"></i>
                    <span class="nav-link-text"><?php echo e(__('Settings')); ?></span>
                </a>
            </li>
        </ul>
        <?php endif; ?>
    </div>
    </div>
</nav><?php /**PATH E:\xampp\htdocs\SmartCitaHome\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>