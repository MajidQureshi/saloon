<div class="container-fluid sidebar_open <?php if($errors->any()): ?> show_sidebar_create <?php endif; ?>" id="add_subscription_sidebar">
    <div class="row">
        <div class="col">
            <div class="card py-3 border-0">
                <div class="border_bottom_pink pb-3 pt-2 mb-4">
                    <span class="h3"><?php echo e(__('Create Subscription')); ?></span>
                    <button type="button" class="add_subscription close">&times;</button>
                </div>
                <form class="form-horizontal" id="create_subscription_form" action="<?php echo e(url('/admin/subscriptions')); ?>"
                    method="post">
                    <?php echo csrf_field(); ?>
                    <div>
                        <div class="form-group">
                            <label class="form-control-label" for="name"><?php echo e(__('Name')); ?></label>
                            <input type="text" value="<?php echo e(old('name')); ?>" name="name" id="name" class="form-control"
                                placeholder="<?php echo e(__('Name')); ?>" autofocus>
                            <div class="invalid-div "><span class="name"></span></div>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="name"><?php echo e(__('Description')); ?></label>
                            <input type="text" value="<?php echo e(old('description')); ?>" name="description" id="description"
                                class="form-control" placeholder="<?php echo e(__('Description')); ?>">
                            <div class="invalid-div "><span class="description"></span></div>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="name"><?php echo e(__('Small Description')); ?></label>
                            <input type="text" value="<?php echo e(old('small_description')); ?>" name="small_description"
                                id="small_description" class="form-control" placeholder="<?php echo e(__('Small Description')); ?>">
                            <div class="invalid-div "><span class="small_description"></span></div>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="name"><?php echo e(__('Old Price')); ?></label>
                            <input type="number" value="<?php echo e(old('old_price')); ?>" name="old_price" id="old_price"
                                class="form-control" placeholder="<?php echo e(__('Old Price')); ?>">
                            <div class="invalid-div "><span class="old_price"></span></div>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="name"><?php echo e(__('New Price')); ?></label>
                            <input type="number" value="<?php echo e(old('new_price')); ?>" name="new_price" id="new_price"
                                class="form-control" placeholder="<?php echo e(__('New Price')); ?>">
                            <div class="invalid-div "><span class="new_price"></span></div>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label" for="name"><?php echo e(__('Fa Icon')); ?></label>
                            <input type="text" value="<?php echo e(old('icon')); ?>" name="icon" id="icon" class="form-control"
                                placeholder="<?php echo e(__('Fa Icon')); ?>">
                            <div class="invalid-div "><span class="icon"></span></div>
                        </div>





                        <div class="text-center">
                            <button type="button" id="create_btn"
                                onclick="all_create('create_subscription_form','subscriptions')"
                                class="btn btn-primary mt-4 mb-5 rtl-float-none"><?php echo e(__('Create')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/admin/subscription/create.blade.php ENDPATH**/ ?>