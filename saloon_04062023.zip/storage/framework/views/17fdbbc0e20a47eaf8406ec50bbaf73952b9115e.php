
<?php $__env->startSection('website_content'); ?>
<?php echo $__env->make('website.layouts.breadcrumb', [
    'title' => __('Profile'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $is_point_package = config('point.active'); ?>
<section class="category-area section--padding">
    <div class="container">
        <div class="container-fluid dashboard-inner-body-container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="block-card dashboard-card mb-4">
                        <div class="block-card-header">
                            <h2 class="widget-title pb-0"><?php echo e(__('layout.Profile Details')); ?></h2>
                        </div>
                        <div class="block-card-body w-100">
                            <form method="post" class="form-box row pt-4" action="<?php echo e(url('/profile-data')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="edit-profile-photo d-flex align-items-center mb-3">
                                    <img src="<?php echo e(Auth::user()->imagePath); ?><?php echo e(Auth::user()->image); ?>" alt="" class="profile-img">
                                    <div class="file-upload-wrap file-upload-wrap-2 ml-4">
                                        <input type="file" name="image" class="multi file-upload-input with-preview">
                                        <span class="file-upload-text"><i class="la la-photo mr-2"></i><?php echo e(__('layout.Upload Photo')); ?></span>
                                    </div>
                                </div><!-- end edit-profile-photo -->
                           
                                <div class="col-lg-12">
                                    <div class="input-box">
                                        <label class="label-text"><?php echo e(__('layout.Your Name')); ?></label>
                                        <div class="form-group">
                                            <span class="la la-user form-icon"></span>
                                            <input class="form-control" type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" placeholder="Name">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                <div class="invalid-div text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="input-box">
                                        <label class="label-text"><?php echo e(__('layout.Your Email')); ?></label>
                                        <div class="form-group">
                                            <span class="la la-envelope-o form-icon"></span>
                                            <input class="form-control" type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" disabled>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="input-box">
                                        <label class="label-text"><?php echo e(__('layout.Phone Code')); ?></label>
                                        <div class="form-group">
                                            <span class="la la-phone form-icon"></span>
                                            <input class="form-control" type="text" name="code" value="<?php echo e(Auth::user()->code); ?>" placeholder="Enter phonecode e.g., +91">
                                            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                <div class="invalid-div text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="input-box">
                                        <label class="label-text"><?php echo e(__('layout.Phone Number')); ?></label>
                                        <div class="form-group">
                                            <span class="la la-phone form-icon"></span>
                                            <input class="form-control" type="text" maxlength="10" name="phone" value="<?php echo e(Auth::user()->phone); ?>" placeholder="Enter phone number">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                <div class="invalid-div text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <?php if($is_point_package == 1): ?>
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text"><?php echo e(__('layout.Referral Code')); ?></label>
                                            <div class="form-group">
                                                <span class="la la-gift form-icon"></span>
                                                <input class="form-control" type="text" name="text" value="<?php echo e(Auth::user()->referral_code); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="col-lg-12">
                                    <div class="btn-box pt-1">
                                        <button class="theme-btn gradient-btn border-0"><?php echo e(__('layout.Save Changes')); ?><i class="la la-arrow-right ml-2"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php if($is_point_package == 1): ?>
                        <div class="block-card dashboard-card mb-4">
                            <div class="block-card-header">
                                <h2 class="widget-title pb-0"> <?php echo e(__('layout.Loyalty Point')); ?> </h2>
                            </div>
                            <div class="block-card-body">
                                <form method="post" class="form-box row">
                                    <div class="col-lg-12">
                                        <div class="input-box">
                                            <label class="label-text"><?php echo e(__('layout.Total Earned Points')); ?></label>
                                            <div class="form-group">
                                                <span class="la la-gift form-icon"></span>
                                                <input class="form-control" type="text" value="<?php echo e(Auth::user()->total_points); ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="input-box">
                                            <label class="label-text"><?php echo e(__('layout.Remaining Points')); ?></label>
                                            <div class="form-group">
                                                <span class="la la-gift form-icon"></span>
                                                <input class="form-control" type="text" value="<?php echo e(Auth::user()->remain_points); ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-6">
                    <div class="block-card dashboard-card mb-4">
                        <div class="block-card-header">
                            <h2 class="widget-title pb-0 display-inline-block"> 
                                <?php echo e(count($addresses) >= 1 ? 'Addresses': 'Address'); ?>

                            </h2>
                            <button class="theme-btn gradient-btn border-0 float-right address_btn" id="add_address"  data-toggle="modal" data-target="#addAddressModal">
                                <i class="la la-plus"></i>
                            </button>
                        </div>
                        <div class="block-card-body">
                            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="<?php echo e($loop->iteration == 1? '':'pt-3'); ?>">
                                <div class="text-color"><i class="la la-map-marker mr-2 text-color-2 font-size-18"></i><?php echo e(__('layout.Address')); ?>

                                     <?php echo e(count($addresses) >= 1 ? $loop->iteration : 'Address'); ?>

                                </div>
                                <div class="display-inline-block pl-4 mt-2">
                                    <?php echo e($item->street); ?>,
                                    <br>
                                    <?php echo e($item->city); ?>, <?php echo e($item->state); ?>, <?php echo e($item->country); ?>

                                </div>
                                <button class="theme-btn gradient-btn border-0 float-right address_btn edit_address mt-4" onclick="DeleteAddress(<?php echo e($item->address_id); ?>)" data-toggle="tooltip" data-placement="top" data-original-title="Delete Address">
                                    <i class="la la-trash"></i>
                                </button>
                                <button class="theme-btn gradient-btn border-0 float-right address_btn edit_address mt-4 mr-2" onclick="OpenAddress(<?php echo e($item->address_id); ?>)" data-toggle="tooltip" data-placement="top" data-original-title="Edit Address">
                                    <i class="la la-pencil"></i>
                                </button>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><!-- end block-card-body -->
                    </div>
                     
                    <div class="block-card dashboard-card mb-4">
                        <div class="block-card-header">
                            <h2 class="widget-title pb-0"><?php echo e(__('layout.Change Password')); ?></h2>
                        </div>
                        <div class="block-card-body">
                            <form method="post" class="form-box row" action="<?php echo e(url('/changePassword')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="col-lg-12">
                                    <div class="input-box">
                                        <label class="label-text"><?php echo e(__('layout.Current Password')); ?></label>
                                        <div class="form-group">
                                            <span class="la la-lock form-icon"></span>
                                            <input class="form-control" type="password" name="current_password" placeholder="Current password" autocomplete="current-password">
                                            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                <div class="invalid-div text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="input-box">
                                        <label class="label-text"><?php echo e(__('layout.New Password')); ?></label>
                                        <div class="form-group">
                                            <span class="la la-lock form-icon"></span>
                                            <input class="form-control" type="password" name="new_password" placeholder="New password" autocomplete="new-password">
                                            <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                <div class="invalid-div text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="input-box">
                                        <label class="label-text"><?php echo e(__('layout.Confirm New Password')); ?></label>
                                        <div class="form-group">
                                            <span class="la la-lock form-icon"></span>
                                            <input class="form-control" type="password" name="confirm_password" placeholder="Confirm new password" autocomplete="new-password">
                                            <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>                                    
                                                <div class="invalid-div text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="btn-box pt-1">
                                        <button type="submit" class="theme-btn gradient-btn border-0"><?php echo e(__('layout.Change Password')); ?><i class="la la-arrow-right ml-2"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $bg_img = \App\AdminSetting::find(1)->bg_img; ?>

<!-- Modal -->
<div class="modal fade modal-container addAddress-form" tabindex="-1" id="addAddressModal" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header align-items-center" style="background-image: url(<?php echo e(asset('storage/images/app/'.$bg_img)); ?>);">
                <h5 class="modal-title" id="addAddressModalTitle"> <?php echo e(__('layout.Add New Address')); ?> </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="la la-times-circle"></span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" class="form-box" id="addAddressForm" action="<?php echo e(url('/addAddress')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="map-container height-400 mb-3">
                        <input type="hidden" value="<?php echo e($setting->lat); ?>" name="latitude" id="latitude">
                        <input type="hidden" value="<?php echo e($setting->lang); ?>" name="longitude" id="longitude">
                        <div id="singleMap" class="drag-map height-400" data-latitude="<?php echo e($setting->lat); ?>" data-longitude="<?php echo e($setting->lang); ?>"></div>
                    </div>
                    <div class="input-box">
                        <label class="label-text"> <?php echo e(__('layout.Street')); ?> </label>
                        <div class="form-group">
                            <span class="la la-user form-icon"></span>
                            <input class="form-control form-control-styled mb-1" type="text" name="street" placeholder="Enter street address">
                            <span class="invalid-div text-danger"><span class="street"></span></span>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text"> <?php echo e(__('layout.City')); ?> </label>
                        <div class="form-group">
                            <span class="la la-user form-icon"></span>
                            <input class="form-control form-control-styled mb-1" type="text" name="city" placeholder="Enter city">
                            <span class="invalid-div text-danger"><span class="city"></span></span>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text"> <?php echo e(__('layout.State')); ?> </label>
                        <div class="form-group">
                            <span class="la la-user form-icon"></span>
                            <input class="form-control form-control-styled mb-1" type="text" name="state" placeholder="Enter state">
                            <span class="invalid-div text-danger"><span class="state"></span></span>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text"> <?php echo e(__('layout.Country')); ?> </label>
                        <div class="form-group">
                            <span class="la la-user form-icon"></span>
                            <input class="form-control form-control-styled mb-1" type="text" name="country" placeholder="Enter country">
                            <span class="invalid-div text-danger"><span class="country"></span></span>
                        </div>
                    </div>
                   
                    <div class="btn-box mb-3">
                        <button type="submit" class="theme-btn gradient-btn w-100" id="submitaddAddress">
                            </i> <?php echo e(__('layout.Add Address')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade modal-container editAddress-form" tabindex="-1" id="editAddressModal" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header align-items-center" style="background-image: url(<?php echo e(asset('storage/images/app/'.$bg_img)); ?>);">
                <h5 class="modal-title" id="editAddressModalTitle"> <?php echo e(__('layout.Edit Address')); ?> </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="la la-times-circle"></span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" class="form-box" id="editAddressForm" action="<?php echo e(url('/editAddress')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="map-container height-400 mb-3">
                        <input type="hidden" value="" name="latitude" id="latitude_edit">
                        <input type="hidden" value="" name="longitude" id="longitude_edit">
                        <div id="singleMapEdit" class="drag-map height-400"></div>
                    </div>
                    <input type="hidden" name="address_id" value="">
                    <div class="input-box">
                        <label class="label-text"> <?php echo e(__('layout.Street')); ?> </label>
                        <div class="form-group">
                            <span class="la la-user form-icon"></span>
                            <input class="form-control form-control-styled mb-1" type="text" name="street" placeholder="Enter street address">
                            <span class="invalid-div text-danger"><span class="street"></span></span>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text"> <?php echo e(__('layout.City')); ?> </label>
                        <div class="form-group">
                            <span class="la la-user form-icon"></span>
                            <input class="form-control form-control-styled mb-1" type="text" name="city" placeholder="Enter city">
                            <span class="invalid-div text-danger"><span class="city"></span></span>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text"> <?php echo e(__('layout.State')); ?> </label>
                        <div class="form-group">
                            <span class="la la-user form-icon"></span>
                            <input class="form-control form-control-styled mb-1" type="text" name="state" placeholder="Enter state">
                            <span class="invalid-div text-danger"><span class="state"></span></span>
                        </div>
                    </div>
                    <div class="input-box">
                        <label class="label-text"> <?php echo e(__('layout.Country')); ?> </label>
                        <div class="form-group">
                            <span class="la la-user form-icon"></span>
                            <input class="form-control form-control-styled mb-1" type="text" name="country" placeholder="Enter country">
                            <span class="invalid-div text-danger"><span class="country"></span></span>
                        </div>
                    </div>
                   
                    <div class="btn-box mb-3">
                        <button type="submit" class="theme-btn gradient-btn w-100" id="submiteditAddress">
                            </i> <?php echo e(__('layout.Edit Address')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('includes/website/js/jquery.MultiFile.min.js')); ?>"></script>
<?php $mapkey = \App\AdminSetting::find(1)->mapkey; ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e($mapkey); ?>"></script>

<script src="<?php echo e(asset('includes/website/js/map-add.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\saloon\saloon\resources\views/website/pages/profile.blade.php ENDPATH**/ ?>